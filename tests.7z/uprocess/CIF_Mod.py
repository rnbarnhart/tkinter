from util.connection import Connection
from util.metrics import Timer
from util.results import Results
from util.logger import Logger
from util.configuration import Configuration
from util.boundingBox import BoundingBox, CoordCalc
from util.layer import Layer
from util.filters import FilterLayer
from util.jobTracker import checkIn, checkOut
from psycopg2.extensions import AsIs
import psycopg2
import itertools
import sys
from collections import defaultdict


class CIF(object):
    def __init__(self, requirement_id, gdb, reviewNumber = None, path = None):
        self.config = Configuration()
        log_opts = self.config.mapSection('Log')
        if not path:
            path = log_opts['path']
        self.log = (Logger(log_opts['name'],path)).getLoggerInstance()
        self.timer = Timer()
        self.overallTimer = Timer()
        self.gdb = gdb
        if not reviewNumber:
            self.reviewNumber = self.getRevNum(requirement_id)
        else:
            self.reviewNumber = reviewNumber
        self.requirement_id = requirement_id
        self.appDbName = self.config.mapSection('Database')['name']
        self.conn = Connection(self.gdb)
        self.stats = False
        self.layerList = {}
        self.filter = FilterLayer()
        self.timeEstimators = {}
        self.resultLogger = Results(self.log, None, self.gdb)
        self.work_mem = 1000



#######################
# SUPPLEMENTAL FUNCTIONS
#######################

# Data retrieve and prep
#-------------
    def retrieveQueries(self, cb):
        """ Retrieve the required queries for the called CIFs and stores them in a dictionary """

        self.log.info('Retrieving applicable CIFs from CIF query db')
        # Connect to query database
        # TODO: Update to correct connection
        conn = Connection('cifquerytest')
        conn.create()
        cursQ = conn.getCursor()

        # Get queries from database

        try:
            testss = tuple(cb)

            queryy = "SELECT * FROM data.queries WHERE title IN %s" %str(testss)
            cursQ.execute(queryy)
            cifs = {}
            for result in cursQ:
                cifs[result[1]]={
                    'id': result[0],
                    'title': str(result[1]),
                    'query': result[10],
                    'layerOne': result[2],
                    'layerTwo': result[3],
                    'layerOneFCode': result[4],
                    'layerTwoFCode': result[5],
                    'vsp': result[6],
                    'ffnIndex': result[7],
                    'invalidLayerOne': result[8],
                    'invalidLayerTwo': result[9],
                    'fcsubtypeOne': result[11],
                    'latlong' : result[12],
                    'fcsubtypeTwo': result[13],
                    'fcsubtypeThree': result[14],
                    'description':str(result[15])
                }
            # print('\nRetrieve Iteration', cifs)
            conn.close()
            return cifs

            # forceList = lambda a : [a] if(type(a) != list) else a

            # # Store them in a dictionary
            # cifs = {}
            # for result in conn.resultIter(cursQ,500):
            #     cifs[result[1]]={
            #         'id': result[0],
            #         'title': str(result[1]),
            #         'query': result[10],
            #         'layerOne': forceList(result[2]),
            #         'layerTwo': forceList(result[3]),
            #         'layerOneFCode': forceList(result[4]),
            #         'layerTwoFCode': forceList(result[5]),
            #         'vsp': forceList(result[6]),
            #         'ffnIndex': forceList(result[7]),
            #         'invalidLayerOne': forceList(result[8]),
            #         'invalidLayerTwo': forceList(result[9]),
            #         'fcsubtypeOne': forceList(result[11]),
            #         'latlong' : result[12],
            #         'fcsubtypeTwo': forceList(result[13]),
            #         'fcsubtypeThree': forceList(result[14]),
            #         'description':str(result[15])
            #     }
            # print('\nRetrieve Iteration', cifs)
            # conn.close()
            # return cifs

        except psycopg2.ProgrammingError as e:
            print "*****Failed to return Queries*****"
            print e


    def setupData(self,cif,layerOne,layerTwo=None):
        """ Setup the SQL query """
        if self.stats:
            sql = 'EXPLAIN (FORMAT JSON) ' + cif['query']
        else:
            sql = "SET cpu_tuple_cost = .003; SET cpu_index_tuple_cost = .005; SET cpu_operator_cost = .0025; SET work_mem = {0}; ".format(self.work_mem)
            sql += cif['query']

        invalidLayerOne, invalidLayerTwo = self.invalidLayers(cif,layerOne,layerTwo)

        data = {
            'layerOne':AsIs(self.layerList[layerOne].name.lower()),
            'layerTwo':AsIs(self.layerList[layerTwo].name.lower()) if layerTwo else '',
            'invalidLayerOne':tuple(invalidLayerOne),
            'invalidLayerTwo':tuple(invalidLayerTwo) if layerTwo else None,
            'layerOneFCode':tuple(cif['layerOneFCode']),
            'layerTwoFCode':tuple(cif['layerTwoFCode']),
            'vsp':tuple(cif['vsp']),
            'ffnIndex':tuple(cif['ffnIndex']),
            'fcsubtypeOne':tuple(cif['fcsubtypeOne']),
            'fcsubtypeTwo':tuple(cif['fcsubtypeTwo']),
            'fcsubtypeThree':tuple(cif['fcsubtypeThree']),
            'cifTitle':cif['title']
            }

        return sql, data

    def getRevNum(self,requirementId):

        conn = Connection('cifquerytest')
        conn.create()
        curs = conn.getCursor()

        curs.execute("SELECT MAX(review_num) FROM results.cif_results WHERE requirement_id = %(requirement_id)s",{'requirement_id':requirement_id})
        prevRev = curs.fetchall()

        conn.close()

        if not prevRev[0][0]:
            return 1
        else:
            return int(prevRev[0][0]) + 1

# Setup Layers
#-------------
    def invalidLayers(self,cif,layerOne,layerTwo=None):
        """ Create invalid layer lists """

        if cif['invalidLayerOne']:
            invalidLayerOne = set(self.layerList[layerOne].invalidFeatures) | set(cif['invalidLayerOne'])
        else:
            invalidLayerOne = self.layerList[layerOne].invalidFeatures

        if layerTwo and cif['invalidLayerTwo']:
            invalidLayerTwo = set(self.layerList[layerTwo].invalidFeatures) | set(cif['invalidLayerOne'])
        elif layerTwo:
            invalidLayerTwo = self.layerList[layerTwo].invalidFeatures
        else:
            invalidLayerTwo = [0]

        if len(invalidLayerOne) == 0:
            invalidLayerOne = [0]
        if len(invalidLayerTwo) == 0:
            invalidLayerTwo = [0]

        return invalidLayerOne, invalidLayerTwo

    def setupLayers(self):

        for layer in self.filter.allLayers:
            # print layer
            self.layerList[layer] = Layer(layer,self.conn,self.requirement_id,self.gdb)
            self.layerList[layer].getInvalidFeatures()
            if not self.layerList[layer].invalidFeatures or len(self.layerList[layer].invalidFeatures) == 0:
                self.layerList[layer].invalidFeatures = [0]

# Prepare and publish results
#-------------
    def results(self,curs):
        """ Format results """

        results = []
        for result in self.conn.resultIter(curs,500):
            results.append(result[0])
        #TODO:
        # if stats:
        #     self.parseResults(results)
        # else:
        return results

    # Uncommented to try and fix table corrections 08/07/2017

    #NEEEEEEEEDDDDDDDD TOOOOOOOO UPDATE TO ADD TABLES
    # def publishResult(self, cif, ogc_fid, layerOne,layerTwo = None ,attr = None):
    #     # str(layerName) can be changed to layerName if results module is changed
    #     result.createResult(layerOne,layerTwo,cif['title'],cif['descript'],ogc_fid, self.requirement_id)
    #     layer = Layer(layerName, Connection(self.gdb), self.requirement_id, self.gdb)
    #     layer.error_count = len(ogc_fid)
    #     resultGrms = Results(self.log, Connection(self.appDbName))
    #     resultGrms.insertCifResults(layer,self.gdb,self.reviewNumber, title, ogc_fid)
    #     print 'finished publish results line 190/CIF_Mod'

    def executeQuery(self, cif, sql, data, curs):
        if not self.conn:
            self.conn.create()
            closeConnection = True
            curs = self.conn.getCursor()
        else:
            closeConnection = False

        # Log query
        # print(sql)

        self.log.debug(curs.mogrify(sql,data))

        # Execute query
        curs.execute(sql,data)

        # Log number of errors
        if not self.stats:
            self.log.info("{errors} errors found in {layerOne}".format(errors=curs.rowcount, layerOne=data['layerOne']))

        # Gather results
        results = self.results(curs)

        # Publish results
        if self.stats:
            # print('\n********Inside CIF_Mod.executeQuery..self.stats********')
            if results:
                self.compileStats(cif['title'],results)
        else:
            # print('\n********Inside CIF_Mod.executeQuery..else********')
            if results:
                self.resultLogger.createResult(layerOne = data['layerOne'],
                                        layerTwo = data['layerTwo'],
                                        title = cif['title'],
                                        description = cif['description'],
                                        ogc_fid = tuple(results),
                                        requirement_id = self.requirement_id,
                                        attr = None)

                # self.resultLogger.insertCifResults(self.layerList[data['layerOne']],self.gdb,self.reviewNumber, cif['title'], tuple(results))

            self.log.debug('{cif} Check on {LayerOne} Results: {results}'.format(cif=cif['title'],LayerOne=data['layerOne'],results=results))

        if closeConnection:
            self.conn.close()

# Multilayer Methods
#-------------
    def multiLayer(self,cif):
        print('****CIF_Mod.multiLayer line 272')
        """ Execute a check on a CIF requiring multiple layers """
        layerPairs = itertools.product(cif['layerOne'],cif['layerTwo'])

        self.timer.startTimer()

        self.conn.create()
        curs = self.conn.getCursor()

        print cif['title']
        for i,j in layerPairs:

            # print('\t' + i + ', ' + j)
            if not self.stats:
                # self.log.info('Checking {cif} on layers {layerOne} and {layerTwo}'.format(cif=cif['title'],layerOne=i,layerTwo=j))
                self.log.info('Checking ' + cif['title'] + ' on layers ' + i + ' and ' + j)
            sql,data = self.setupData(cif,i,j)

            self.executeQuery(cif,sql,data, curs)

        self.conn.close()

        self.timer.stopTimer()

        if not self.stats:
            self.log.info('{cif} check runtime: {time}'.format(cif=cif['title'],time=self.timer.getRunTime()))

            statsConn = Connection("cifquerytest")
            statsConn.create()
            statsCurs = statsConn.getCursor()

            publishTime = "UPDATE results.jobstats SET actual_runtime = %(runtime)s WHERE requirement_id = %(requirement_id)s AND review_num = %(review_num)s AND check_title = %(check_title)s"
            data = {'runtime': self.timer.getRunTime(),
                    'requirement_id': self.requirement_id,
                    'review_num': self.reviewNumber,
                    'check_title': cif['title']}

            try:
                statsCurs.execute(publishTime,data)
            except psycopg2.ProgrammingError as e:
                print "Failed to log actual runtime."
                print e
            statsConn.close()

# Single Layer Methods
#-------------
    def singleLayer(self,cif):
        """ Execute a check on a CIF requiring only one layer """

        # Start timer to track runtime
        self.timer.startTimer()

        self.conn.create()
        curs = self.conn.getCursor()

        # Create the layer
        for layer in cif['layerOne']:

            if not self.stats:
                self.log.info('Checking {cif} on layer {layer}'.format(cif=cif['title'],layer=layer))

            # Setup the query
            sql,data = self.setupData(cif,layer)

            print('\n',cif)
            # print(sql)
            # print(data)
            # print(curs)

            self.executeQuery(cif,sql,data,curs)

        self.conn.close()

        self.timer.stopTimer()

        if not self.stats:
            self.log.info('{cif} check runtime: {time}'.format(cif=cif['title'],time=self.timer.getRunTime()))
            statsConn = Connection("cifquerytest")
            statsConn.create()
            statsCurs = statsConn.getCursor()

            publishTime = "UPDATE results.jobstats SET actual_runtime = %(runtime)s WHERE requirement_id = %(requirement_id)s AND review_num = %(review_num)s AND check_title = %(check_title)s"
            data = {'runtime': self.timer.getRunTime(),
                    'requirement_id': self.requirement_id,
                    'review_num': self.reviewNumber,
                    'check_title': cif['title']}

            try:
                statsCurs.execute(publishTime,data)
            except psycopg2.ProgrammingError as e:
                print "Failed to log actual runtime."
                print e
            statsConn.close()

# allOtherIllegalFaces Methods
#-------------
    def allOtherIllegalFaces(self,cif):
        print('****CIF_Mod.allotherillegalfaces Line 369')
        """This function preserves the 'allOtherIllegalFaces' method in CIF1"""
        #TODO: This should be rewritten as a better sql query instead of loops

        # Connect to the cifquery database
        # TODO: Replace hardcoded 'cifquerytest' with correct database (config.ini?)
        fclassnames = Connection('cifquerytest')
        fclassnames.create()

        self.conn.create()
        self.timer.startTimer()
        curs = self.conn.getCursor()

        for layerOne in cif['layerOne']:
            print('\t****',layerOne)
            fcodecurs = fclassnames.getCursor()
            fcodecurs.execute('SELECT * FROM data.fclassnames WHERE UPPER(layer) = UPPER(%(layer)s)',{'layer':layerOne})
            fcodes = {}

            for fcode in fcodecurs.fetchall():
                fcodes[fcode[0]]={
                    'fcode':fcode[0],
                    'feature':fcode[1],
                    'related':fcode[3]
                }

            fcodecurs.close()


            for layerTwo in cif['layerTwo']:

                if not self.stats:
                    self.log.info('Checking {cif} on layers {layerOne} and {layerTwo}'.format(cif=cif['title'],layerOne=layerOne,layerTwo=layerTwo))

                sql,data = self.setupData(cif,layerOne,layerTwo)

                for i,fid in enumerate(fcodes.values()):
                    if i > 0:
                        sql += " OR "
                    else:
                        sql += " AND "
                    sql += " (a.f_code = '"+ fid['fcode'] + "' AND b.f_code in ('" + "','".join(str(x) for x in fid['related']) + "'))"

                self.executeQuery(cif,sql,data,curs)

        self.timer.stopTimer()

        if not self.stats:
            self.log.info('{cif} check runtime: {time}'.format(cif=cif['title'],time=self.timer.getRunTime()))
            statsConn = Connection("cifquerytest")
            statsConn.create()
            statsCurs = statsConn.getCursor()

            publishTime = "UPDATE results.jobstats SET actual_runtime = %(runtime)s WHERE requirement_id = %(requirement_id)s AND review_num = %(review_num)s AND check_title = %(check_title)s"
            data = {'runtime': self.timer.getRunTime(),
                    'requirement_id': self.requirement_id,
                    'review_num': self.reviewNumber,
                    'check_title': cif['title']}

            try:
                statsCurs.execute(publishTime,data)
            except psycopg2.ProgrammingError as e:
                print "Failed to log actual runtime."
                print e
            statsConn.close()

        self.conn.close()
        fclassnames.close()

# latLongCheck Methods
#-------------
    def runLatLongCheck(self, cif, layer, cord, span):
        print('****CIF_Mod.runLatLongCheck Line 441')
        """ Check CIF requing lat/long check """
        #TODO: Log?
        sql, data = self.setupData(cif,layer)

        if not self.stats:
            self.log.info('Checking {cif} on layers {layerOne}'.format(cif=cif['title'],layerOne=layer))
        self.conn.create()
        curs = self.conn.getCursor()
        self.timer.startTimer()
        # resultPub = Results(self.log, Connection(self.gdb))
        # resultGrms = Results(self.log, Connection(self.appDbName))
        currentLayer = self.layerList[layer]
        #Not sure what this line does, was in original CIF:
        #if layer.ogc:
        results = []
        for i in span:
            data['latlongdegvarPlus'] = i + cord
            data['latlongdegvarMin'] = i - cord


            self.log.debug(curs.mogrify(sql,data))
            curs.execute(sql,data)
            if not self.stats:
                self.log.info("{errors} errors found in {layerOne}".format(errors=curs.rowcount,layerOne=layer))
            result = self.results(curs)

            results += result

        if self.stats:
            if results:
                self.compileStats(cif['title'],results)
        else:
            if results:
                self.resultLogger.createResult(layerOne = data['layerOne'],
                                        layerTwo = data['layerTwo'],
                                        title = cif['title'],
                                        description = cif['description'],
                                        ogc_fid = tuple(results),
                                        requirement_id = self.requirement_id,
                                        attr = None)
                # Uncommented to try and fix table corrections 08/07/2017
                # self.publishResult(cif['title'],tuple(results),currentLayer.name)
            self.log.debug('{cif} Check on {LayerOne} Results: {results}'.format(cif=cif['title'],LayerOne=layer,results=result))

        self.conn.close()
        self.timer.stopTimer()
        if not self.stats:
            self.log.info('{cif} check runtime: {time}'.format(cif=cif['title'],time=self.timer.getRunTime()))
            statsConn = Connection("cifquerytest")
            statsConn.create()
            statsCurs = statsConn.getCursor()

            publishTime = "UPDATE results.jobstats SET actual_runtime = %(runtime)s WHERE requirement_id = %(requirement_id)s AND review_num = %(review_num)s AND check_title = %(check_title)s"
            data = {'runtime': self.timer.getRunTime(),
                    'requirement_id': self.requirement_id,
                    'review_num': self.reviewNumber,
                    'check_title': cif['title']}

            try:
                statsCurs.execute(publishTime,data)
            except psycopg2.ProgrammingError as e:
                print "Failed to log actual runtime."
                print e
            statsConn.close()

    def latLongCheck(self,cif):
        print('****CIF_Mod.latLongCheck Line 509')
        """ Setup for a latLongCheck """

        #TODO: is there a better way to declare these? (Maybe pull from ini?)
        avglatmeter = 0.0
        avglongmeter = 0.0
        proximityvar = 0.10
        maxdistvar = 50.00
        mindistvar = 10.00

        bbox = BoundingBox(self.requirement_id,self.gdb,self.reviewNumber) 
        cifCalc = CoordCalc(self.gdb, proximityvar, maxdistvar,mindistvar,avglatmeter,avglongmeter)

        self.timer.startTimer()

        # May be able to roll the folowing into singleLayer()
        for i in cif['layerOne']:
            uResults = bbox.boundBox(i)
            if uResults:
                latdegvar, maxlongdegvar, minlongdegvar, longdegvar, maxlatdegvar, minlatdegvar,intxspan, intyspan = cifCalc.latlongcalc(uResults, i)
        if longdegvar and intyspan:
            for i in cif['layerOne']:
                self.runLatLongCheck(cif,i,longdegvar,intyspan)
        if latdegvar and intxspan:
            for i in cif['layerOne']:
                self.runLatLongCheck(cif,i,latdegvar,intxspan)

        self.timer.stopTimer()

        if not self.stats:
            self.log.info('{cif} check runtime: {time}'.format(cif=cif['title'],time=self.timer.getRunTime()))

# nulSubattributeCheck Methods
# #-------------
    def getNullSubattributeCriteria(self):
        print('****CIF_Mod.getNullSubattributeCriteria Line 543')
        conn = Connection('cifquerytest')
        conn.create()
        curs = conn.getCursor()
        curs.execute('SELECT * FROM data.nullsubattributecrit')
        results = curs.fetchall()
        criteria = defaultdict(dict)
        for result in results:
            criteria[result[0]][result[1]] = {'charvars':result[2],
                                                'numbers':result[3]}
        conn.close()
        return criteria

    def nullSubattributeCheck(self,cif):
        print('****CIF_Mod.nullSubattributeCheck Line 557')

        criteria = self.getNullSubattributeCriteria()

        self.timer.startTimer()

        self.conn.create()
        curs = self.conn.getCursor()

        for layer in cif['layerOne']:

            if not self.stats:
                self.log.info('Checking {cif} on layer {layer}'.format(cif=cif['title'],layer=layer))

            sql, data = self.setupData(cif,layer)

            for subtype, nulls in criteria[layer].items():
                if len(nulls['charvars']) > 0:

                    subsql = sql

                    for i, subattr in enumerate(nulls['charvars']):

                        if i > 0:
                            subsql += " OR"
                        subsql +=  " {0} = 'No Information' or {0} = 'noInformation' or {0} = 'UNK' or {0} = 'None' or {0} = 'N_A' or {0} IS NULL".format(subattr)

                    data['subtype'] = AsIs(subtype)

                    self.executeQuery(cif,subsql,data,curs)

                if len(nulls['numbers']) > 0:

                    subsql = sql

                    for i, subattr in enumerate(nulls['numbers']):

                        if i > 0:
                            subsql += " OR"
                        subsql +=  " {0} = -999999 or ({0} >= 996.0 and {0} <= 999.0) or ({0} <= -32764.0 and {0} >= -32768.0) or ({0} <= -2147483644.0 and {0} >= -2147483648.0) or {0} IS NULL".format(subattr)

                    data['subtype'] = AsIs(subtype)

                    self.executeQuery(cif,subsql,data,curs)

        self.conn.close()

        self.timer.stopTimer()

        if not self.stats:
            self.log.info('{cif} check runtime: {time}'.format(cif=cif['title'],time=self.timer.getRunTime()))
            statsConn = Connection("cifquerytest")
            statsConn.create()
            statsCurs = statsConn.getCursor()

            publishTime = "UPDATE results.jobstats SET actual_runtime = %(runtime)s WHERE requirement_id = %(requirement_id)s AND review_num = %(review_num)s AND check_title = %(check_title)s"
            data = {'runtime': self.timer.getRunTime(),
                    'requirement_id': self.requirement_id,
                    'review_num': self.reviewNumber,
                    'check_title': cif['title']}

            try:
                statsCurs.execute(publishTime,data)
            except psycopg2.ProgrammingError as e:
                print "Failed to log actual runtime."
                print e
            statsConn.close()

# illogAttributes Methods
#---------------
    def getIllogAttributesCriteria(self, layer):
        print('****CIF_Mod.getIllogAttributesCriteria Line 628')
        critConn = Connection('cifquerytest')
        critConn.create()
        critCurs = critConn.getCursor()

        critSql = "SELECT subtype,subatt1,subatt2,values1,values2, singleattribute, singleattributevalue FROM data.illogicalAttributeCriteria WHERE upper(layer) = upper(%(layerOne))s"
        critCurs.execute(critSql,{'layerOne': layer})

        criteria = critCurs.fetchall()
        critConn.close()

        return criteria

    def illogAttributes(self,cif):
        print('****CIF_Mod.illogAttributes Line 643')

        self.timer.startTimer()

        self.conn.create()
        curs = self.conn.getCursor()

        for layer in cif['layerOne']:

            criteria = self.getIllogAttributesCriteria(layer)

            if not self.stats:
                self.log.info('Checking {cif} on layer {layer}'.format(cif=cif['title'],layer=layer))

            sqlStr = 'SELECT ogc_fid FROM %(layerOne)s WHERE '
            for i, crit in enumerate(criteria):
                if i > 0:
                    sqlStr += " OR "

                if crit[5]:
                    sqlStr += "(f_code = '" + crit[0] + "' AND " + crit[1] + " = '" + str(crit[6]) + "')"
                else:
                    if len(crit[4]) > 1:
                        values2 = ",".join(str(x) for x in crit[4])
                    else: values2 = str(crit[4][0])
                    sqlStr += "(f_code = '" + crit[0] + "' AND " + crit[1] + " = '" + str(int(crit[3])) + "' AND " + crit[2] + " IN (" + values2 + "))"

            if layer == 'UtilityInfrastructureCrv':
                sqlStr += " OR (f_code = 'AQ113' AND NPL >= 3 AND RTA IN (-999999,1,2,999))"
            if layer == 'TransportationGroundCrv':
                sqlStr += " OR (f_code = 'AN010' AND LTN >= 3 AND RTA IN (-999999,1,2,999))"

            if self.stats:
                sqlStr = 'EXPLAIN (FORMAT JSON) ' + sqlStr

            self.log.info('Checking for IllogicalAttributes on {layerOne}'.format(layerOne=layer))
            self.log.debug('Connection to Database created.')

            # Layer two is added to satisfy executeQuery
            data = {'layerOne': AsIs(layer), 'layerTwo': None}

            self.executeQuery(cif, sqlStr,data,curs)

        self.conn.close()

        self.timer.stopTimer()

        if not self.stats:
            self.log.info('{cif} check runtime: {time}'.format(cif=cif['title'],time=self.timer.getRunTime()))
            statsConn = Connection("cifquerytest")
            statsConn.create()
            statsCurs = statsConn.getCursor()

            publishTime = "UPDATE results.jobstats SET actual_runtime = %(runtime)s WHERE requirement_id = %(requirement_id)s AND review_num = %(review_num)s AND check_title = %(check_title)s"
            data = {'runtime': self.timer.getRunTime(),
                    'requirement_id': self.requirement_id,
                    'review_num': self.reviewNumber,
                    'check_title': cif['title']}

            try:
                statsCurs.execute(publishTime,data)
            except psycopg2.ProgrammingError as e:
                print "Failed to log actual runtime."
                print e
            statsConn.close()

# Stats Specific Methods
#-------------

    def compileStats(self,checkTitle, sqlResults):
        # print('****CIF_Mod.complileStats Line 712')

        for result in sqlResults:
            plan = result[0]['Plan']
            self.timeEstimators[checkTitle] = {
                                                "p_tot_cost": plan['Total Cost'],
                                                "p_st_cost": plan['Startup Cost'],
                                                "p_rows": plan['Plan Rows'],
                                                "p_width": plan['Plan Width'],
                                                "op_count": 1,
                                                "row_count": plan['Plan Rows']
            }
            if 'Plans' in plan:
                self.parseQueryOperations(plan['Plans'],checkTitle)

    def parseQueryOperations(self,plans,checkTitle):
        # print('****CIF_Mod.parseQueryOperations Line 728')
        for plan in plans:
            node_type = "_".join(plan['Node Type'].split(" ")).lower()
            node_count = node_type + "_count"
            node_rows = node_type + "_rows"
            if node_count in self.timeEstimators[checkTitle]:
                self.timeEstimators[checkTitle][node_count] += 1
                self.timeEstimators[checkTitle][node_rows] += plan['Plan Rows']

            else:
                self.timeEstimators[checkTitle][node_count] = 1
                self.timeEstimators[checkTitle][node_rows] = plan['Plan Rows']
            self.timeEstimators[checkTitle]['op_count'] += 1
            self.timeEstimators[checkTitle]['row_count'] += plan['Plan Rows']
            if 'Plans' in plan:
                self.parseQueryOperations(plan['Plans'],checkTitle)

    def publishStats(self):
        print('****CIF_Mod.publishStats Line 746')

        statsConn = Connection('cifquerytest')
        statsConn.create()
        statsCurs = statsConn.getCursor()

        # insertStats = 'INSERT INTO jobstats (requirement_id, review_num, check_title, p_tot_cost, p_st_cost, p_rows, p_width, op_count, row_count) VALUES (%(requirement_id)s, %(review_num)s, %(check_title)s, %(p_tot_cost)s, %(p_st_cost)s, %(p_rows)s, %(p_width)s, %(op_count)s, %(row_count)s)'
        for checkTitle, results in self.timeEstimators.items():
            data = {}
            # Setup the SQL statement. Iterates through keys to capture applicable columns
            insertStats = "INSERT INTO results.jobstats (requirement_id, review_num, check_title, "
            insertStatsValues = ") VALUES (%(requirement_id)s, %(review_num)s, %(check_title)s, "
            for i, key in enumerate(results.keys()):
                col_name = "_".join(key.split(" ")).lower()
                if i > 0:
                    insertStats += ', '
                insertStats += col_name
                if i > 0:
                    insertStatsValues += ', '
                insertStatsValues += '%({})s'.format(col_name)
                data[col_name] = results[key]
            insertStats += insertStatsValues

            # insertStats += ') VALUES ('
            # for i,key in enumerate(results.keys()):
            #     if i > 0:
            #         insertStats += ', '
            #     insertStats += '%(' + key +')s'
            insertStats += ')'

            # Prepare the data dictionary to be used in the execute call
            data['check_title'] = checkTitle
            data['requirement_id'] = self.requirement_id
            data['review_num'] = self.reviewNumber

            print statsCurs.mogrify(insertStats,data)
            # Attempt to insert results, if this fails make sure the appropriate columns
            # exist, if not add them.
            try:
                statsCurs.execute(insertStats,data)
                print "{} stats added".format(checkTitle)
            except psycopg2.ProgrammingError as e:
                print e
                print data
                for nodeName, nodeType in self.timeEstimators[checkTitle].items():
                    try:
                        statsCurs.execute("ALTER TABLE results.jobstats ADD COLUMN %(nodeName)s int",{'nodeName':AsIs(nodeName)})
                        print "Added column {}".format(nodeName)
                    except psycopg2.ProgrammingError as e:
                        print e
                        print "{} already exists".format(nodeName)
        statsConn.close()
        self.statsPublished = True

# Currently unused
#-------------
    def statusUpdate(self):
        print('****CIF_Mod.statusUpdate Line 803')
        """ Came from original CIF, currently unused """
        #TODO: Logic to verify title is not none.
        result = Results(self.log, Connection(self.appDbName))
        result.updateCifStatus(self.title, self.reviewNumber, self.requirement_id, self.gdb)

#######################
# MAIN METHODS
#######################
    def runChecks(self, org_cb, jobID):
        print('****CIF_Mod.runChecks Line 813')
        """ Main function """
        if not self.stats:
            self.work_mem = checkIn(jobID)
            print('SELF.WORK_MEM = ',self.work_mem)

        # self.log.info('Running CIF_Mod')
        self.overallTimer.startTimer()

        if not hasattr(org_cb,'__iter__'):
            cb = [org_cb]

        self.cifs = self.retrieveQueries(org_cb)

        self.setupLayers()


        # Cycle through the required cifs
        for title,cif in self.cifs.items():
            # print('****CIF_Mod.runChecks row 832',cif)

        # Check for multiple layers
            if title == 'allotherillegalfaces':
                # print('*******',title)
                self.allOtherIllegalFaces(cif)
            elif title == 'nullsubattributecheck':
                # print('*',title)
                self.nullSubattributeCheck(cif)
            elif title == 'illogAttributes':
                # print('**',title)
                self.illogAttributes(cif)
            elif cif['latlong']:
                # print('***',cif)
                self.latLongCheck(cif)
            elif cif['layerOne'] and cif['layerTwo']:
                # print('****',cif)
                self.multiLayer(cif)
            else:
                print('*****',cif)
                self.singleLayer(cif)

        self.overallTimer.stopTimer()
        self.log.info('CIF_Mod complete. Runtime: {time}'.format(time=self.overallTimer.getRunTime()))

        if not self.stats:
            checkOut(jobID)

    def runStats(self, org_cb, jobID):
        print ("****CIF_Mod.runStats Line 861")
        self.stats = True
        self.runChecks(org_cb, jobID)
        print ("runStats/runChecks Completed")
        self.publishStats()
        print ("runStats/publishStats Completed")
        self.stats = False

#######################
# Temporary Changes to imports
#######################
# THESE SHOULD BE IMPLEMENTED IN THE PARENT CLASSES INSTEAD OF RESIDING HERE.

#######################
# For Testing Purposes Only
#######################

if __name__ == "__main__":
    '''
    Devnote: This is for integration into the existing structure.
        Eventually, remove this conditional and only use this __main__ for testing/other relevant logic .
    '''

    path = 'test.log'
    requirement_id = '170620_Data'
    gdb_name = 'AFG_Test'
    review_num = '102'
    cif = CIF(requirement_id,gdb_name,review_num,path)
    # conn = Connection('cifquerytest')
    # conn.create()
    # curs = conn.getCursor()
    # curs.execute("SELECT title FROM data.queries")
    # cb = []
    # for result in curs.fetchall():
    #     cb.append(result[0])
    # conn.close()
    cb = ["islandCheck"]
    cif.runStats(cb)
    cif.runChecks(cb)


#######################
# Improvement Ideas
#######################

# May be able to clean up how results are sent.
