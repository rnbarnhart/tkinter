from util.connection import Connection

def getApplicableChecks(requirement_id,rev_num, user_input = None, group = 'All'):

    # Setup connection/cursor
    dataConn = Connection('cifquerytest')
    dataConn.create()

    # Get checklist
    checklist = getGroupChecks(group, dataConn)

    checklist = getRequestedChecks(user_input, checklist)

    emptyLayers = getEmptyLayers(requirement_id, rev_num, dataConn)

    checkLayers = getCheckLayers(checklist, dataConn)

    return getChecks(emptyLayers, checkLayers)

def getGroupChecks(group, conn):
    # Queries database to retrieve checks based on group

    dataCurs = conn.getCursor()

    groupSql = "SELECT * FROM data.groupCheckKey where groupName = %(group)s"

    dataCurs.execute(groupSql,{'group': group})

    checks = [desc[0] for desc in dataCurs.description if desc[0] not in ('idx','groupname')]

    results = [res for res in dataCurs.fetchall()[0]][2:]

    return [check[0] for check in zip(checks,results) if check[1]]

    dataCurs.close()

def getRequestedChecks(user_input,checklist):
    # Determines which checks to run based on user input and group checks

    #TODO: Need to determine how we want to implement this. How are checks determined?
    # User input should trump all

    if user_input:
        return set(user_input)
    else:
        return set(checklist)

def getEmptyLayers(requirement_id,rev_num, conn):
    # Get all layers with at least 1 feature.
    
    dataCurs = conn.getCursor()

    layerSql = "SELECT * FROM results.lyr_featurecount WHERE requirement_id = %(requirement_id)s AND review_num = %(rev_num)s"

    dataCurs.execute(layerSql,{'requirement_id':requirement_id, 'rev_num':rev_num})

    layers = [desc[0] for desc in dataCurs.description][4:]

    featureCounts = [count for count in dataCurs.fetchall()[0]][4:]

    return [layer[0] for layer in zip(layers,featureCounts) if layer[1] == 0]

def getCheckLayers(checklist, conn):
    # Returns which layers are required by the checks in the checklist

    checkDict = {}
    dataCurs = conn.getCursor()

    checkSql = 'SELECT title, layerone, layertwo FROM data.queries where title in %(checklist)s'

    dataCurs.execute(checkSql,{'checklist':tuple(checklist)})

    results = dataCurs.fetchall()

    for title, layerone, layertwo in results:
        checkDict[title] = {'layerone':layerone,
                            'layertwo': layertwo}

    dataCurs.close()

    return checkDict

def getChecks(nonEmptyLayers,checkLayers):
    # Determine which checks are applicable based on which layers are nonempty
    applicableChecks = set()

    for title,layers in checkLayers.items():

        if bool(set(layers['layerone']) - set(nonEmptyLayers)):
            if layers['layertwo'] == 0:
                applicableChecks.add(title)
            elif bool(set(layers['layertwo']) - set(nonEmptyLayers)):
                applicableChecks.add(title)

    return applicableChecks

