from CIF_Mod import CIF
from generator import GeoJson
import unzipper
# from django.utils import timezone
from gdbtodb import gdbTodb
from util.connection import Connection
from layerPrecheck import Precheck
# from django.db import models
import os, shutil, csv ############################### Need to replace os function
import applicableChecks
from psycopg2.extensions import AsIs
# from grip.settings import MEDIA_ROOT
# from django.conf import settings
import datetime, re, subprocess, psycopg2
from subprocess import call



def run_checks(jobID, job, rev, checks, org_checks):

    print('*Inside run_checks')

    cif_job = CIF(
        requirement_id = jobID,
        gdb = job,
        reviewNumber = str(rev))

    print('**CIF Instance created')
    try:
        cif_job.runStats(org_checks, jobID)
    except psycopg2.ProgrammingError as e:
        print "Failed to complete runStats"
        print e
        job_reset(jobID, rev, 'results.jobstats')
        return None

    try:
        cif_job.runChecks(org_checks, jobID)
    except psycopg2.ProgrammingError as e:
        print "Failed to complete runChecks"
        print e
    # except:
    #     print 'Checks failed'
        job_reset(jobID, rev, 'results.jobstats')
        job_reset(jobID, rev, 'results.cif_results')
        return None

    print('Checks complete')

    try:
        results_location = convert_to_geojson(job)
    except psycopg2.ProgrammingError as e:
        print 'Convert to GeoJSON failed'
        print e
        job_reset(jobID, rev, 'results.jobstats')
        job_reset(jobID, rev, 'results.cif_results')
        return None

    print('conversion done')
    return results_location

def convert_to_geojson(job):

    print "Converting to JSON"
    file_to_convert = GeoJson(job) 
    print 'GeoJson created'

    file_location = file_to_convert.getOutput()

    print file_location
    print 'File converted'

    # shutil is not threadsafe
    shutil.make_archive(job, 'zip', file_location)#***************************************Fixed And Run Again

    print 'File archived'

    return file_location

def initialize(job):
    print job
    #job = Job.objects.filter(jobID = jobId).filter(rev = rev)
    unzipped_file = unzipper.unzipfile(job)
    # print MEDIA_ROOT
    # unzipped_filepath = MEDIA_ROOT + "/temp/" + unzipped_file
    unzipped_filepath = job[0:-4]

    # Call created text file with the required info for precheck script
    with open(os.path.join(os.path.dirname(job), 'job_info.txt')) as f:
        reader = csv.reader(f, delimiter='\t')
        for l in reader:
            jobID = str(l[0])
            gdb=str(l[1])
            GIS_DB = str(l[2])
            precheck_time = l[3]
            rev = str(l[4])
            checks = str(l[5])

    pg_connection = Connection('postgres')
    pg_connection.create()
    print 'created connection'

    converter = gdbTodb()
    print 'calling converter'
    converter.createDB(GIS_DB,pg_connection)
    print 'created database'
    converter.exportGDBtoPosgreSQL(unzipped_filepath, GIS_DB)
    print '\nconverted to PostgreSQL'
    # job = GIS_DB

    precheck = Precheck(jobID,GIS_DB,rev)
    print 'precheck created'
    precheck.multi()
    print 'precheck complete'

    connthree = Connection('cifquerytest')
    connthree.create()
    cursthree = connthree.getCursor()

    query = 'INSERT INTO public.precheck_job ("jobID", original_file, rev, create_date, user_id, applicable_checks, gdb_name)'\
        'VALUES (%(job)s, %(gdb)s, %(rev)s, %(create_date)s, %(user_id)s, %(checks)s, %(gdb_name)s);'
    cursthree.execute(query,
            {
            'job': str(jobID),
            'gdb':gdb + '.zip',
            'rev':rev,
            'create_date': precheck_time,
            'user_id':1,
            'checks':checks,
            'gdb_name':GIS_DB
            })
    connthree.close()

    applicable_checks = ", ".join(applicableChecks.getApplicableChecks(jobID,rev))

    # job.save()

    shutil.rmtree(unzipped_filepath)
    print unzipped_filepath + ' removed'
    # os.remove(os.path.join(os.path.dirname(job), 'job_info.txt'))
    # print 'Job info file removed'

    return job

def job_reset(jobID, rev , table):

    data = {'requirement_id': jobID,
            'review_num': str(rev),
            'table': AsIs(table)}

    sql = "DELETE FROM %(table)s WHERE requirement_id = %(requirement_id)s AND review_num = %(review_num)s"

    connect = Connection('cifquerytest')
    connect.create()
    curs = connect.getCursor()

    print curs.mogrify(sql,data)
    curs.execute(sql,data)

    connect.close()

    print("Reset {}".format(table))

def export2shp(GIS_DB):
    table = []
    conn_export = Connection(GIS_DB)
    conn_export.create()
    curs_export = conn_export.getCursor()

    # sql_export = "SELECT * FROM information_schema.tables WHERE TABLE_NAME LIKE '%crv' OR TABLE_NAME LIKE '%pnt' OR TABLE_NAME LIKE '%srf';"
    sql_export = "SELECT * FROM information_schema.tables WHERE TABLE_NAME LIKE '%_results_geom';"
    curs_export.execute(sql_export)
    for rows in curs_export:
        table.append(rows[2])
    conn_export.close()
    print table
    for layer in table:
        try:
            print layer
            source = ("'" + 'pgsql2shp -f /home/barnharn/uprocess/media/temp/' + layer + ' -h localhost -u postgres -P postgres ' + GIS_DB + ' "' + 'SELECT * FROM public.' + layer + '"' + "'")
            os.system(("'" + source + "'"))
            # subprocess.call("'" + source + "'", shell=True)
            # source1 = ('ogr2ogr -f "ESRI Shapefile" /home/barnharn/uprocess/media/temp/' + layer + '1.shp' + ' PG:' + '"'+'host=localhost user=postgres password=postgres dbname=' + GIS_DB + '" ' + '-sql'+' "' + 'SELECT * FROM public.' + layer + '"')
            # print source1
            # subprocess.call(source1, shell=True)
            # os.system(source1)
            print "shapefile exported"
        except psycopg2.ProgrammingError as e:
            print e
        