#######################################################################################################
##
##   Authors: Michael Tackett, Theodore Terry, George Jarvis, Bob Meartz
##
##   Date: May 01, 2017
##
##   Written in Python 2.7.5, SQL portions are PostgreSQL 9.3 with PostGIS
##
##   Overall Python Dependencies (imports): CongParser, os   
##
##   File name: configuration.py
##
##   Description: Module reads and parses config.ini file for proper execution of CIF engine and 
##                individual application 
#######################################################################################################

import ConfigParser
import os
'''
Configuration Class
'''
class Configuration: 
	def __init__(self, path=None):
		'''
		: Description: Initialization module. Controls the initialization of the layer instance
		
		: type self: instance variable
		: param self: refers to the reference of an instance variable used syntactically
		
		: type path: string
		: param path: path of config.ini, defaulted to none 
		'''		
		self.Config = ConfigParser.ConfigParser()
		if not path: 
			#Try to find the config file locally. 
			path = 'config.ini'
		path = os.getenv('CONFIG', path)
		self.Config.read(path)

	#See python/org/moin/ConfigParserExample
	def mapSection(self,section):
		'''
		: Description: Initialization module. Controls the initialization of the layer instance
		
		: type self: instance variable
		: param self: refers to the reference of an instance variable used syntactically
		
		: type section: section
		: param section: contains the name of the section to be process in order to obtain the
 		:                proper configration variable		                 
		'''		
		configDict = {}
		options = self.Config.options(section)
		for option in options:
			try:
				configDict[option] = self.Config.get(section,option)
				if configDict[option] == -1:
					self.log.info('Config option ({option}) not found. '.format(option=option))
			except: 
				self.log.error('Exception with config option: {option}'.format(option=option))
				configDict[option] = None
		return configDict

#For testing. 
if __name__ == '__main__':
	config = Configuration()
	print config.mapSection('Application')
