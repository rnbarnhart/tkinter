import psycopg2
from psycopg2 import sql
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT, AsIs
from connection import Table, Connection
from logger import Logger
from layer import Layer
from configuration import Configuration

class Results():
    def __init__(self, logger, conn, gdb=None):
        self.config = Configuration()
        log_opts = self.config.mapSection('Log')
        self.log = (Logger(log_opts['name'], log_opts['path'])).getLoggerInstance()
        self.gdb = gdb
        self.conn = None
        self.curs = None
        if conn:
            self.conn = conn
            self.conn.create()
            self.curs = self.conn.getCursor()

    def createResult(self, layerOne, layerTwo, title, description, ogc_fid, requirement_id, attr = None):
        print("\n****results.createResult Line 23****")
        if not self.conn:
            conn = Connection(self.gdb)
            conn.create()
            curs = conn.getCursor()
        else:
            curs = self.curs

        table = Table(self.gdb,'{layer}_results_geom'.format(layer=layerOne))
        print(table.name)

        if not table.tableExists():
            table.createTable()
            table.close()
        elif not table.updated():
            table.updateTable()
            table.close()

        query = 'with a as (select ogc_fid, geom from %(layer)s where ogc_fid in %(ogc_fid)s) '\
                    'insert into %(layer)s_results_geom(cif_title, cif_description, assocLayer, attr, ogc_fid, requirement_id, geom)'\
                    'select %(cif_title)s, %(cif_descript)s, %(assocLayer)s, %(attr)s, a.ogc_fid, %(requirement_id)s, ST_MULTI(a.geom) from a'

        data = {'layer':AsIs(layerOne),
                'cif_descript': description,
                'assocLayer': str(layerTwo),
                'attr': attr,
                'cif_title':title,
                'ogc_fid': ogc_fid,
                'requirement_id':requirement_id}

        self.log.debug(curs.mogrify(query,data))

        curs.execute(query,data)

        if layerTwo:
            print(layerTwo)

            table = Table(self.gdb,'{layer}_results_geom'.format(layer=layerTwo))
            print(table)

            if not table.tableExists():
                table.createTable()
                table.close()
            elif not table.updated():
                table.updateTable()
                table.close()
                data['layer'] = AsIs(layerTwo)
                data['assocLayer']= str(layerOne)

            self.log.debug(curs.mogrify(query,data))

            curs.execute(query,data)

       # curs.close()

    # def createResultsGeom(self,layer, title, ogc_fid, requirement_id, geom):
    #     if not self.conn:
    #         conn = Connection(self.gdb)
    #         conn.create()
    #         curs = conn.getCursor()
    #     else:
    #         curs = self.curs
    #     query = 'INSERT INTO %(layer)s_results_geom (cif_title, ogc_fid, layer_name, '\
    #             'requirement_id, geom) values (%(cif_title)s, %(ogc_fid)s, '\
    #             '%(layer_name)s, %(requirement_id)s, %(geom)s);'
    #     self.log.debug(curs.mogrify(query,
    #         {
    #         'layer':AsIs(layer.lower()),
    #         'cif_title':title,
    #         'ogc_fid': ogc_fid,
    #         'requirement_id':requirement_id,
    #         'layer_name': layer,
    #         'geom': geom
    #         }))

    #     curs.execute(query,  {
    #         'layer':AsIs(layer.lower()),
    #         'cif_title':title,
    #         'ogc_fid': ogc_fid,
    #         'requirement_id':requirement_id,
    #         'layer_name': layer,
    #         'geom': geom
    #         })

    def insertResults(self, requirement_id, layer_name, feature_ids,
        gdb_name, check_type, review_num, variance, results_wms_url):
        if not self.conn:
            conn = Connection(self.gdb)
            conn.create()
            curs = conn.getCursor()
        else:
            curs = self.curs
        query = 'INSERT INTO results.cif_results (requirement_id, layer_name, '\
                    'feature_id, comp_time, gdb_name, check_type, review_num, '\
                    'variance, results_wms_url) VALUES (%(requirement_id)s, '\
                    '%(layer_name)s, \'{%(feature_ids)s}\', localtimestamp, %(gdb_name)s, '\
                    '%(check_type)s, %(review_num)s, %(variance)s, %(results_wms_url)s);'
        self.log.debug(curs.mogrify(query,
            {
            'requirement_id':requirement_id,
            'layer_name':layer_name,
            'feature_ids':AsIs(feature_ids),
            'gdb_name':gdb_name,
            'check_type':check_type,
            'review_num':review_num,
            'variance':variance,
            'results_wms_url':results_wms_url
            }))
        
        curs.execute(query,
            {
            'requirement_id':requirement_id,
            'layer_name':layer_name,
            'feature_ids':AsIs(feature_ids),
            'gdb_name':gdb_name,
            'check_type':check_type,
            'review_num':review_num,
            'variance':variance,
            'results_wms_url':results_wms_url
            })
       # self.conn.commit()
        
    def calculateVariance(self, layer):
        total_elements = int(layer.getTotalElementCount()[0])
        error_count = layer.getErrorCount()
        self.log.debug('Layer {name}: {fids} total ogc_fids, {errors} total errors'
            .format(name=layer.name, fids = total_elements, errors=error_count))
        return str(float(error_count*100)/float(total_elements) if total_elements != 0 else 0)

    def insertResultsGeom(self,layer):
       self.log.debug('Updating GDB results tables: ')
       table = Table(layer.gdb,'{layer}_results_geom'.format(layer=layer.name.lower()))
       if not table.tableExists():
            table.createTable()
            table.close()
       for name, ogc_fid, geom, title, checkName in layer.errors:
           self.log.debug('%s %s %s %s' %(name, ogc_fid, title,checkName))        
           self.createResultsGeom(name, title, ogc_fid, layer.requirement_id, geom)      

    def insertCifResults(self, layer, gdb, reviewNumber, check_type, fids = None):
       self.log.info('Publishing Results for: {name}'.format(name=layer.name)) 
       ogc_fids = list()
       if fids:
            ogc_fids = fids
       else:
           for name, ogc_fid, geom, title, checkName in layer.errors:
               ogc_fids.append(ogc_fid)
       if ogc_fids:
           variance = self.calculateVariance(layer)
           url = layer.getWmsUrl()
           fid_list = ','.join([str(x) for x in ogc_fids])
           self.insertResults( layer.requirement_id, layer.name,  
                fid_list, gdb, check_type, reviewNumber, variance, url)
    
    def insertRowGeom(self,layerName, ogc_fid, geom, title, requirement_id, checkName):
       self.log.debug('Updating GDB results tables: ')
       self.createResultsGeom(layerName, title, ogc_fid, requirement_id, geom)      

    def insertTiming(self, cifId, reviewNumber, gdb, time):
        if not self.conn:
            conn = Connection(self.gdb)
            conn.create()
            curs = conn.getCursor()
        else: 
            curs = self.curs

        sql = 'UPDATE cif.cif_estimation '\
                'SET total_time = %(time)s, '\
                'run_status = \'Complete\' '\
                'WHERE review_num = %(reviewNum)s '\
                'AND gdb_name = %(gdb)s '\
                'AND cif_num = %(cifNum)s'

        self.log.debug(curs.mogrify(sql,
            {
            'time':time,
            'reviewNum':reviewNumber,
            'gdb':gdb,
            'cifNum':cifId
            }))
        
        curs.execute(sql,
            {
            'time':time,
            'reviewNum':reviewNumber,
            'gdb':gdb,
            'cifNum':cifId
            })

    def copyCifResults(self,layerName,gdb,reviewNumber, title, requirement_id):
        self.log.info('Copying Results for: {name}'.format(name=layerName)) 
        layer = Layer(layerName, Connection(gdb), requirement_id, gdb)
        sql = 'Select ogc_fid from %(layer)s_results_geom;'
        if not self.conn:
            conn = Connection(self.gdb)
            conn.create()
            curs = conn.getCursor()
        else: 
            curs = self.curs

        self.log.debug(curs.mogrify(sql,
            { 'layer':AsIs(layerName.lower()), }
        ))
        try: 
            curs.execute(sql,
                { 'layer':AsIs(layerName.lower()), }
            )
            layer.fid_list = curs.fetchall()
            layer.error_count = curs.row_count

            variance = self.calculateVariance(layer)
            url = layer.getWmsUrl()
            fid_list = ','.join([str(x) for x in ogc_fids])

            self.insertResults(layer.requirement_id, layer.name,  
                layer.fid_list, gdb, check_type, reviewNumber, variance, url)
        except:
            return 

    def updateCifStatus(self, title, reviewNumber, requirement_id, gdb):
        self.log.info('Updating database with cif status')       
        self.log.debug('Connection to Database created.')
        if not self.conn:
            conn = Connection(self.config.mapSection('Database')['name'])
            conn.create()
            curs = conn.getCursor()
        else: 
            curs = self.curs

        sql = 'UPDATE cif.cif_status '\
                'SET check_type = %(title)s '\
                'WHERE review_num = %(review_num)s '\
                'AND requirement_id = %(requirement_id)s '\
                'AND gdb_name = %(gdb_name)s'

        self.log.debug(curs.mogrify(
            sql, {
                'title':title,
                'review_num': reviewNumber,
                'requirement_id': requirement_id,
                'gdb_name': gdb
                }
        )) 

        curs.execute(
            sql, {
                'title':title,
                'review_num': reviewNumber,
                'requirement_id': requirement_id,
                'gdb_name': gdb
                }        
        ) 
        curs.close()

    def __del__(self):
        if self.curs:
            self.curs.close()
            self.conn.close()
