import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT, AsIs

class Layer(object):
    def __init__(self, name, conn, requirement_id, gdb):
        self.name = name
        self.conn = conn
        self.invalidFeatures = None
        self.ogc = None
        self.error_count = None
        self.errors = list()
        self.requirement_id = requirement_id
        self.gdb = gdb
        self.fCode = None
    
    def getInvalidFeatures(self):
        conn = self.conn
        conn.create()
        curs = conn.getCursor()
        curs.execute('SELECT ogc_fid FROM %(table)s WHERE not ST_Isvalid(geom) '\
                 'or geom is null;',{'table':AsIs(self.name)} )
        for val in curs:
            print('*********layer.getInvalidFeatures', val)
        result = curs.fetchall()
        conn.close() 
        self.invalidFeatures = [i[0] for i in result]
        print(self.invalidFeatures)
        return self.invalidFeatures

    def getOGC(self):
        conn = self.conn
        conn.create()
        curs = conn.getCursor()
        curs.execute('SELECT DISTINCT ogc_fid FROM %(table)s;',{'table':AsIs(self.name)} )
        result = curs.fetchall()
        conn.close() 
        self.ogc_fid = [i[0] for i in result]
        return self.ogc_fid
    
    def getTotalElementCount(self):
        conn = self.conn
        conn.create()
        curs = conn.getCursor()
        query = 'SELECT COUNT(ogc_fid) FROM %(layer)s'
        #self.log.debug(self.curs.mogrify(query,{'layer':AsIs(self.name)}))
        curs.execute(query,{'layer':AsIs(self.name)})
        return curs.fetchone()
    
    def addError(self,ogc_fid, geom, cifTitle, checkName):
        self.errors.append((self.name, ogc_fid, geom, cifTitle, checkName))
    
    def getWmsUrl(self):
        return 'http://164.214.197.129:8080/geoserver/{layer}/wms'.format(layer=self.gdb) 

    def getErrorCount(self):
        if self.errors:
            return len(self.errors)
        else: 
            return self.error_count