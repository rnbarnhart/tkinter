import pandas as pd

def checkIn(requirement_id):
    df = pd.read_csv(r'util/jobTracker.csv',header=0)

    if requirement_id in df.requirement_id:
        return df[df.requirement_id == requirement_id]['work_mem']

    else:
        nextAvailable = df.requirement_id.last_valid_index()
        if nextAvailable:
            nextAvailabe += 1
        else:
            nextAvailable = 0

        df.loc[nextAvailable,'requirement_id'] = requirement_id

        df.to_csv(r'util/jobTracker.csv',index=False)

        return df[df.requirement_id == requirement_id]['work_mem'][0]

def reassignMemory(requirement_id, df):
    delReqID = df[df['requirement_id'] == requirement_id].index.tolist()[0]
    lastReqID = df.requirement_id.last_valid_index()

    for i in range(delReqID,lastReqID):
        df.loc[i,'requirement_id'] = df.loc[i+1,'requirement_id']

    df.loc[lastReqID,'requirement_id'] = None

    return df

def checkOut(requirement_id):
    df = pd.read_csv(r'util/jobTracker.csv',header=0)

    if requirement_id not in df.values:
        return

    else:
        reassignMemory(requirement_id,df)
        df.to_csv(r'util/jobTracker.csv',index=False)


