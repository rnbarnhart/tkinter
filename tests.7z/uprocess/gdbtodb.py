import psycopg2
import subprocess, sys, time
from psycopg2 import sql
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT, AsIs
from util.logger import Logger
from util.configuration import Configuration

class gdbTodb():
    def __init__(self):
        self.config = Configuration()
        opts = self.config.mapSection('CIF_Database')
        self.host = opts['host']
        self.port = opts['port']
        self.user = opts['user']
        self.passwd = opts['passwd']
        self.dbtype = opts['dbtype']
        self.schema = opts['schema']

    # def checkForExistingDB (self,dbToFind,cursor):
    #     #self.log.info("In checking for existing DB")
    #     try:
    #         cursor.execute("SELECT datname FROM pg_database WHERE datistemplate = false") # Creates a list of all databases on the Psycopg connection instance
    #     except Exception, e:
    #         self.log.debug("Error %s"%e)
    #     else:
    #         for listOfDBs in cursor: 
    #             if listOfDBs[0] == dbToFind:
    #                 cursor.execute("DROP DATABASE {}".format(dbToFind))
    #                 return
    #     #self.log.info("check for exiting DB complete")
    #     return

    def createDB(self, GIS_DB, pg_connection):
        pg_cursor = pg_connection.getCursor()
        pg_cursor.execute("CREATE DATABASE {}".format(GIS_DB))
        pg_connection.close()

        connection = psycopg2.connect("dbname={} user={} password={} host={}".format(GIS_DB, self.user, self.passwd, self.host))
        cursor = connection.cursor()
        cursor.execute("CREATE EXTENSION postgis")
        cursor.execute("ALTER TABLE geometry_columns OWNER TO {}".format(self.user))
        cursor.execute("ALTER TABLE spatial_ref_sys OWNER TO {}".format(self.user))
        connection.commit()

    def exportGDBtoPosgreSQL(self, sourceDatabaseFile, GIS_DB):
        #Import data
        # print("Exporting GDB to PostgreSQL\n")
        #Construct OGR terminal screen command to convert GDB to PosgreSQL
        print sourceDatabaseFile
        print GIS_DB
        dbDestinationArgs = "-f \"PostgreSQL\" PG:\"host=" + self.host + " port=5432 dbname=" + GIS_DB + " user=" + self.user + " password=" + self.passwd + "\""
        ogrCmd = "ogr2ogr " + dbDestinationArgs + " " + sourceDatabaseFile + " -t_srs EPSG:4326 -progress -preserve_fid -lco GEOMETRY_NAME=geom -lco SPATIAL_INDEX=YES --config PG_USE_COPY YES"
        #Kick off OGR command as a process with progress bar
        try:
            process = subprocess.Popen(ogrCmd, stdout=subprocess.PIPE, shell=True)
            while process.poll() is None:
                print("."),
                sys.stdout.flush()
                time.sleep(1)       
            (out, error) = process.communicate()
            sys.stdout.flush()
        except:
            print("Export GDB to PostgreSQL failed.")
            pass

        return

    def removeGDB(GDBfileName):
        destFolder = "//mnt/public/SFD_Projects/CIF_Pool/Archive/"
        #self.log.info("\nGDB File to remove: {gdbfilename}\n".format(gdbfilename=GDBfileName))
        #print "GDBFILENAME = ", GDBfileName
        #call(["rm -rf " + GDBfileName],shell=True)
    
