from osgeo import ogr
import os, sys
from osgeo import gdal

#Reference: https://pcjericks.github.io/py-gdalogr-cookbook
#Database needs to be created prior to running convert
def convert(gdb_path):
    # use OGR specific exceptions
    gdal.UseExceptions()
    gdal.SetConfigOption('PG_USE_COPY', 'YES')
    connectionString = "PG:dbname='%s' user='%s' password='%s' port=5432 host=localhost" % ('bob','postgres','postgres')
    outDataSource = ogr.Open(connectionString)
    options = ['OVERWRITE=YES','GEOMETRY_NAME=geom','SPATIAL_INDEX=YES']

    # get the driver
    driver = ogr.GetDriverByName("OpenFileGDB")

    # opening the FileGDB
    try:
        gdb = driver.Open(gdb_path, 0)
    except Exception, e:
        print e
        sys.exit()

    # parsing layers by index
    for featsClass_idx in range(gdb.GetLayerCount()):
        featsClass = gdb.GetLayerByIndex(featsClass_idx)
        newLayer = outDataSource.CreateLayer(featsClass.GetName(),featsClass.GetSpatialRef(),ogr.wkbUnknown,options)
        print featsClass.GetName()
        #Create layer attributes to match what is currently in GDB.
        for x in xrange(featsClass.GetLayerDefn().GetFieldCount()):
            newLayer.CreateField(featsClass.GetLayerDefn().GetFieldDefn(x))
        sourceFeature = featsClass.GetNextFeature()
        
        newLayer.StartTransaction() 
        y = 0
        while sourceFeature is not None: 
            newFeature = ogr.Feature(newLayer.GetLayerDefn()) 
            for i in xrange(featsClass.GetLayerDefn().GetFieldCount()):
                newFeature.SetField(featsClass.GetLayerDefn().GetFieldDefn(i).GetNameRef(),sourceFeature.GetField(i))
                if y % 128 == 0: 
                    newLayer.CommitTransaction() 
                    newLayer.StartTransaction() 
                y = y + 1
            newFeature.SetGeometry(sourceFeature.GetGeometryRef())
            newFeature.SetFID(sourceFeature.GetFID())
            newLayer.CreateFeature(newFeature) 
            sourceFeature = featsClass.GetNextFeature()
            del newFeature

        newLayer.CommitTransaction()

    # clean close
    del gdb  
    del outDataSource

if __name__ == '__main__':
    convert('441TDS_v6_1_1_SYR_01A_FGCM_DO0014_441PS.gdb')
