##**************************************************************
## Program Name: dbCleanup.py
##   External Python Dependencies (imports): psycopg2, multiprocessing, itertools
##
##   File name: dbcleanup.py
##
##   Called from TK_GUI program
##
##   Description: Database and file cleanup
##
##**************************************************************
import sys, time, os
import ConfigParser
from subprocess import Popen, PIPE
from time import sleep
from util.logger import Logger
from util.metrics import Timer
from util.configuration import Configuration
from multiprocessing import Process, Queue
from datetime import datetime
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
from psycopg2 import connect
import signal
import glob
import shlex, errno, traceback, shutil
from os.path import getmtime


class dbCleanup():

    def __init__(self, scandays):
        self.xdeldays = scandays
        self.config = Configuration()
        log_opts = self.config.mapSection('Log')
        path = 'Log/'
        if not path:
            path = log_opts['path']
        self.log = (Logger('testLogger',path)).getLoggerInstance()
        #self.log = logging.basicConfig(filename= 'cif.log',level=logging.DEBUG)
        print "Here..."
        print scandays
        
        
    def days_between(self, d1, d2):
        d1 = datetime.strptime(d1, "%Y-%m-%d")
        d2 = datetime.strptime(d2, "%Y-%m-%d")
        return abs((d2 - d1).days)

    
    def dbconnect(self):
        db_opts = self.config.mapSection("Database")
        self.name = db_opts['name']
        self.user = db_opts['user']
        self.password = db_opts['passwd']
        self.host = db_opts['host']
        self.cursor = None
        self.connection = psycopg2.connect('dbname={} user={} password={} '\
            ' host={}'.format(self.name, self.user, self.password, self.host))
        self.connection.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        return True

    def chkdb(self, deldays):
        localtime = time.localtime()
        timeString = time.strftime("%Y/%m/%d %H:%M:%S", localtime)
        cur = condb()
        try:
            cur.execute("select p.datname, p.pid, (pg_stat_file('base/'||d.oid||'/PG_VERSION')).modification as datecreated "
                    "from pg_stat_activity p INNER JOIN pg_database d on d.datname = p.datname "
                    "where d.datname like 'gdb%';")
                   
        except Exception, e:
            logging.info("%s CHKDB: Error in attempting to select data %s"%(timeString,e))
        else:
            for row in cur.fetchall():
                localtime = time.localtime()
                timeString = time.strftime("%Y/%m/%d %H:%M:%S", localtime)
                currentDate = datetime.now().strftime("%Y-%m-%d")

                dbDate = str(row[2])[:10]
                daysdiff = self.days_between(dbDate, currentDate)
                if int(daysdiff) >= int(deldays):
                    try:
                        cur.execute("select pg_terminate_backend('"+ row[1] + "' from pg_stat_activity where pg_stat_activity.datname = '" + row[0] + "';")
                        
                    except Exception, e:
                        self.log.info("%s CHKDB: Kill command not executed. Error %s:"%(timeString, e))
                    else:
                        self.log.info("%s CHKDB: Kill command on pid [%s] successfully executed for database %s."%(timeString, row[1],row[0]))
                    try:
                        cur.execute("drop database {dbname}".format(dbname=row[0]))
                    except Exception, e:
                        self.log.info("%s CHKDB: Unable to drop database %s"%(timeString, e))
                    else:
                        self.log.info("%s CHKDB: Database [%s] successfully dropped."%(timeString, row[0]))

    def is_int(x):
        return x == int(x)


    def chklog(self, deldays):
        dirs = os.listdir("//mnt/public/SFD_Projects/CIF_Pool/Logfile")
        localtime = time.localtime()
        timeString = time.strftime("%Y/%m/%d %H:%M:%S", localtime)
        x = 0
        for file in dirs:
            fileDate = datetime.fromtimestamp(getmtime("//mnt/public/SFD_Projects/CIF_Pool/Logfile/"+file)).strftime('%Y-%m-%d')
            currentDate = datetime.now().strftime("%Y-%m-%d")
            daysdiff = self.days_between(fileDate, currentDate)
            if (int(daysdiff) >= int(deldays)):
                try:
                    #os.remove("//mnt/public/SFD_Projects/CIF_Pool/Logfile/"+file)
                    print "//mnt/public/SFD_Projects/CIF_Pool/Logfile/"+file
                except Exception, e:
                    self.log.info("%s ChkLog: Unable to delete file %s"%(timeString, e))
                    print "%s ChkLog: Unable to delete file %s"%(timeString, e)
                else:
                    self.log.info("%s ChkLog: File [%s] successfully deleted. "%(timeString, file))
                    print "%s ChkLog: File [%s] successfully deleted. "%(timeString, file)


    def chkarchive(self, deldays):
        dirs = os.listdir("//mnt/public/SFD_Projects/CIF_Pool/Archive")
        localtime = time.localtime()
        timeString = time.strftime("%Y/%m/%d %H:%M:%S", localtime)
        x = 0
        for file in dirs:
            fileDate = datetime.fromtimestamp(getmtime("//mnt/public/SFD_Projects/CIF_Pool/Archive/"+file)).strftime('%Y-%m-%d')
            currentDate = datetime.now().strftime("%Y-%m-%d")
            daysdiff = self.days_between(fileDate, currentDate)
            if (int(daysdiff) >= int(deldays)):
                try:
                    #os.remove("//mnt/public/SFD_Projects/CIF_Pool/Archive/"+file)
                    print "//mnt/public/SFD_Projects/CIF_Pool/Archive/"+file
                except Exception, e:
                    self.log.info("%s ChkArchive: Unable to delete file %s"%(timeString, e))
                    print "%s ChkArchive: Unable to delete file %s"%(timeString, e)
                else:
                    self.log.info("%s ChkArchive: File [%s] successfully deleted. "%(timeString, file))
                    print "%s ChkArchive: File [%s] successfully deleted. "%(timeString, file)
                    
                 