#!/usr/bin/python2.7
import os, sys, datetime, time
from datetime import datetime

import json
import xml
import subprocess
import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
import xml.etree.cElementTree as ET
import xml.etree.ElementTree as xml
from lxml import etree
import logging, multiprocessing, signal
import ConfigParser
import glob 
import Tkinter # Python GUI package
import tkFileDialog # for Dialog Box
import traceback # for error checking
import tkMessageBox
import shlex, errno
import Config
from Config import configure, configure_after
import Publish
from subprocess import call

from geoserver.catalog import Catalog

appname = 'cifbot'
pidfile = '//mnt/public/SFD_Projects/CIF_Production/pid/' + appname + '.pid'
logfile1 = '//mnt/public/SFD_Projects/CIF_Production/log/' + appname + '.log'
logging.basicConfig(filename=logfile1,level=logging.DEBUG)

myFormats = [('ESRI GeoDatabase', '*.gdb'),]

global allLayerList
allLayerList = ["AeronauticCrv", "AeronauticPnt", "AeronauticSrf", "AgriculturePnt", "AgricultureSrf", "BoundaryPnt", "BoundarySrf", "CultureCrv", 'CulturePnt', "CultureSrf", "FacilityPnt", "FacilitySrf", "HydroAidNavigationPnt", "HydroAidNavigationSrf", "HydrographyCrv", "HydrographyPnt", "HydrographySrf", "HypsographyCrv", "HypsographyPnt", "IndustryCrv", "IndustryPnt", "IndustrySrf", "InformationCrv", "InformationPnt", "InformationSrf", "MilitaryCrv", "MilitaryPnt", "MilitarySrf", "PhysiographyCrv", "PhysiographyPnt", "PhysiographySrf", "PortHarbourCrv", "PortHarbourPnt", "PortHarbourSrf", "RecreationCrv", "RecreationPnt", "RecreationSrf", "SettlementPnt", "SettlementSrf", "StoragePnt", "StorageSrf", "StructureCrv", "StructurePnt", "StructureSrf", "SubterraneanSrf", "TransportationGroundCrv", "TransportationGroundPnt", "TransportationGroundSrf", "TransportationWaterCrv", "TransportationWaterPnt", "TransportationWaterSrf", "UtilityInfrastructureCrv", "UtilityInfrastructurePnt", "UtilityInfrastructureSrf", "VegetationCrv", "VegetationPnt", "VegetationSrf", "MetadataSrf", "ResourceSrf"]
global relLayers
relLayers = []
#......................................................................................................
global allSrfLayerList
allSrfLayerList = ["AeronauticSrf", "AgricultureSrf", "BoundarySrf", "CultureSrf", "FacilitySrf", "HydroAidNavigationSrf", "HydrographySrf", "IndustrySrf", "InformationSrf", "MilitarySrf", "PhysiographySrf", "PortHarbourSrf", "RecreationSrf", "SettlementSrf", "StorageSrf", "StructureSrf", "SubterraneanSrf", "TransportationGroundSrf", "TransportationWaterSrf", "UtilityInfrastructureSrf", "VegetationSrf", "MetadataSrf", "ResourceSrf"]
global allCrvLayerList
allCrvLayerList = ["AeronauticCrv", "TransportationGroundCrv", "HydrographyCrv", "CultureCrv", "HypsographyCrv", "IndustryCrv", "InformationCrv", "MilitaryCrv", "PortHarbourCrv", "RecreationCrv", "StructureCrv", "TransportationWaterCrv", "UtilityInfrastructureCrv", "VegetationCrv", "PhysiographyCrv"]
###"AeronauticCrv", "CultureCrv", "HydrographyCrv", "HypsographyCrv", "IndustryCrv", "InformationCrv", "MilitaryCrv", "PortHarbourCrv", "RecreationCrv", "StructureCrv", "TransportationGroundCrv", "TransportationWaterCrv", "UtilityInfrastructureCrv", "VegetationCrv"]
################################# TESTING
global halfCrvLayerList1
halfCrvLayerList1 = ["HydrographyCrv", "AeronauticCrv", "CultureCrv", "HypsographyCrv", "IndustryCrv", "InformationCrv", "MilitaryCrv"] 
global halfCrvLayerList2
halfCrvLayerList2 = ["TransportationGroundCrv", "PhysiographyCrv", "PortHarbourCrv", "RecreationCrv", "StructureCrv", "TransportationWaterCrv", "UtilityInfrastructureCrv", "VegetationCrv"] #"StructureCrv", 
################################# TESTING
global allSrfCrvList
allSrfCrvList = ["AeronauticSrf", "AgricultureSrf", "BoundarySrf", "CultureSrf", "FacilitySrf", "HydroAidNavigationSrf", "HydrographySrf", "IndustrySrf", "InformationSrf", "MilitarySrf", "PhysiographySrf", "PortHarbourSrf", "RecreationSrf", "SettlementSrf", "StorageSrf", "StructureSrf", "SubterraneanSrf", "TransportationGroundSrf", "TransportationWaterSrf", "UtilityInfrastructureSrf", "VegetationSrf", "MetadataSrf", "ResourceSrf", "AeronauticCrv", "CultureCrv", "HydrographyCrv", "HypsographyCrv", "IndustryCrv", "InformationCrv", "MilitaryCrv", "PhysiographyCrv", "PortHarbourCrv", "RecreationCrv", "StructureCrv", "TransportationGroundCrv", "TransportationWaterCrv", "UtilityInfrastructureCrv", "VegetationCrv"]
###'PhysiographySrf',  
global allPntLayerList
allPntLayerList = ["AeronauticPnt", "AgriculturePnt", "BoundaryPnt", 'CulturePnt', "FacilityPnt", "HydroAidNavigationPnt", "HydrographyPnt", "HypsographyPnt", "IndustryPnt", "InformationPnt", "MilitaryPnt", "PhysiographyPnt", "PortHarbourPnt", "RecreationPnt", "SettlementPnt", "StoragePnt", "StructurePnt", "TransportationGroundPnt", "TransportationWaterPnt", "UtilityInfrastructurePnt", "VegetationPnt"]
#......................................................................................................
filter1 = ('TransportationGroundSrf', 'IndustrySrf', 'AgricultureSrf', 'HydrographySrf', 'VegetationSrf', 'MilitarySrf', 'SettlementSrf', 'HydroAidNavigationSrf', 'InformationSrf', 'AeronauticSrf', 'PhysiographySrf', 'RecreationSrf', 'UtilityInfrastructureSrf', 'StorageSrf', 'PortHarbourSrf', 'FacilitySrf', 'SubterraneanSrf', 'CultureSrf', 'TransportationWaterSrf', 'StructureSrf', 'BoundarySrf')
#......................................................................................................
grdtrans3 = ["TransportationGroundSrf", "TransportationGroundCrv", "TransportationGroundPnt"]
bldg3 = ["StructureCrv", "StructurePnt", "StructureSrf"]
#......................................................................................................
hydro4 = ["HydrographyCrv", "HydrographyPnt", "HydrographySrf"]
bldg4 = ["StructureCrv", "StructurePnt", "StructureSrf"]
#......................................................................................................
grdtrans5 = ["TransportationGroundSrf", "TransportationGroundCrv", "TransportationGroundPnt"]
hydro5 = ["HydrographyCrv", "HydrographyPnt", "HydrographySrf"]
#......................................................................................................
filter6 = ["TransportationGroundCrv"]
#......................................................................................................
filter7 = ['AgricultureSrf', 'HydrographySrf', 'IndustrySrf', 'InformationSrf', 'SettlementSrf', 'TransportationWaterSrf', 'VegetationSrf'] ###'PhysiographySrf', 
#......................................................................................................
global cif11CrvLayerList
cif11CrvLayerList = ["HydrographyCrv"]
###"AeronauticCrv", "CultureCrv", "HydrographyCrv", "HypsographyCrv", "IndustryCrv", "InformationCrv", "MilitaryCrv", "PhysiographyCrv", "PortHarbourCrv", "RecreationCrv", "StructureCrv", "TransportationGroundCrv", "TransportationWaterCrv", "UtilityInfrastructureCrv", "VegetationCrv"]
#......................................................................................................
filter19 = ["TransportationGroundCrv"]
#......................................................................................................
filter20 = ["TransportationGroundCrv"]
#......................................................................................................
filter25 = ["HydrographySrf", "HydrographyCrv", "TransportationWaterCrv", "TransportationWaterSrf", "TransportationGroundCrv", "TransportationGroundPnt"]
#......................................................................................................
filter27 = ["FacilityPnt", "FacilitySrf", "StructureCrv", "StructurePnt", "StructureSrf"]
#......................................................................................................

global relRules
relRules = []
global review_num
global z2
z2 = []

#......................................................................................................

def importvariables(mode):
    global sourceDatabaseFile
    global xmlPathString
    global logFilePathString
    global dbName
    global schema
    global dbUser
    global dbUserPw
    global dbHost
    global dbConnectionArgs
    global rdbName
    global rschema
    global rdbConnectionArgs
    global gui
    sourceDatabaseFile = Config.sourceDatabaseFile
    xmlPathString = Config.xmlPathString
    logFilePathString = Config.logFilePathString
    dbName = Config.dbName
    schema = Config.schema
    dbUser = Config.dbUser
    dbUserPw = Config.dbUserPw
    dbHost = Config.dbHost
    dbConnectionArgs = Config.dbConnectionArgs
    rdbName = Config.rdbName
    rschema = Config.rschema
    rdbConnectionArgs = Config.rdbConnectionArgs
    if mode == "develop":
        gui = Config.gui

#......................................................................................................

def writeLogEntry(msg, logfile):
    
    logfile.write((datetime.now().strftime("%Y-%m-%d_%H:%M:%S.%f ==>  ") + msg + "\n"))
    return

#......................................................................................................

def computeElapsedTime(startTime, endTime):
    
    fmt = "%H:%M:%S.%f"
    elapsedTime = datetime.strptime(endTime, fmt) - datetime.strptime(startTime, fmt)
    return elapsedTime

#......................................................................................................
        
def formatIntegerToString (num):
    
    return "{:,}".format(num)

#......................................................................................................

def checkForExistingDB (dbToFind,cursor):
    logging.info("In checkForExistingDB")
    try:
        cursor.execute("SELECT datname FROM pg_database WHERE datistemplate = false") # Creates a list of all databases on the Psycopg connection instance
    except Exception, e:
        logging.info("Error %s"%e)
    else:
        logging.info("check 1")
        for listOfDBs in cursor: 
            if listOfDBs[0] == dbToFind:
                cursor.execute("DROP DATABASE {}".format(dbToFind))
                return
        logging.info("Done")
        return

#......................................................................................................

def exportGDBtoPosgreSQL(logfile, sourceDatabaseFile, GIS_DB):

    #Import data
    writeLogEntry("Exporting GDB to PostgreSQL.",logfile)
    print "Exporting GDB to PostgreSQL data.\n"
    #Construct OGR terminal screen command to convert GDB to PosgreSQL
    dbDestinationArgs = "-f \"PostgreSQL\" PG:\"host=" + dbHost + " port=5432 dbname=" + GIS_DB + " user=" + dbUser + " password=" + dbUserPw + "\""
    ogrCmd = "ogr2ogr " + dbDestinationArgs + " " + sourceDatabaseFile + " -t_srs EPSG:4326 -progress -preserve_fid -lco GEOMETRY_NAME=geom -lco SPATIAL_INDEX=YES --config PG_USE_COPY YES"
    #Kick off OGR command as a process with progress bar
    try:
        process = subprocess.Popen(ogrCmd, stdout=subprocess.PIPE, shell=True)
        while process.poll() is None:
            #print("\b."),
            print("."),
            sys.stdout.flush()
            time.sleep(1)       
        (out, error) = process.communicate()
        sys.stdout.flush()

    except:
        print "fail"

    return



#......................................................................................................

def writexml(company,sourceDatabaseFile,xmlPath):
    vendor = xml.Element("vendor")
    vendorinfo = xml.Element("vendorinfo")
    vendor.append(vendorinfo)
    vendorname = xml.SubElement(vendorinfo, "vendorname")
    vendorname.text = company
    vendormeta = xml.SubElement(vendorinfo, "vendormeta")
    street = xml.SubElement(vendormeta, "street")
    street.text = "1601 Pennsylvania Ave."
    email = xml.SubElement(vendormeta, "email")
    email.text = "test1@test.com"
    vendorfile = xml.Element("vendorfile")
    vendor.append(vendorfile)
    filename = xml.SubElement(vendorfile, "filename")
    filename.text = sourceDatabaseFile
    filesize = xml.SubElement(vendorfile, "filesize")
    filesize.text = "Find file size function"
    filedate = xml.SubElement(vendorfile, "filedate")
    filedate.text = xmlPath
    vendorparam = xml.Element("vendorparam")
    vendor.append(vendorparam)
    tree = xml.ElementTree(vendor)
    with open(xmlPath, "w") as path:
        tree.write(path)
    path.close()
#......................................................................................................

def appendxml(rule, descr, xmlPath):
    tree = xml.ElementTree(file=xmlPath)
    root = tree.getroot()
    param = xml.Element("param")
    for item in root.iter("vendorparam"):
        item.append(param)
    ruleid = xml.SubElement(param, "ruleid")
    ruleid.text = rule
    desc = xml.SubElement(param, "desc")
    desc.text = descr
    tree = xml.ElementTree(root)
    with open(xmlPath, "w") as editpath:
        tree.write(editpath)
    editpath.close()

#......................................................................................................

def prettyPrintXml(xmlFilePath):
    assert xmlFilePath is not None
    parser = etree.XMLParser(resolve_entities=False, strip_cdata=False)
    document = etree.parse(xmlFilePath, parser)
    document.write(xmlFilePath, pretty_print=True, encoding='utf-8')

#.....................................................................................................

def boundbox(logfile, cursor):
    boundingbox = []
    boundingboxcord = []
    for layer in allLayerList:
        cursor.execute("SELECT ST_Extent(geom) FROM " + layer)
        if (cursor.rowcount > 0):
            rec = cursor.fetchone()
            while rec is not None:
                #eliminates the layers that are empty
                if rec[0] is not None:
                    relLayers.append(layer)
                    boundingbox.append(rec[0])
                rec = cursor.fetchone()
  
    for boxes in boundingbox:
        boxes = boxes.translate(None, "BOX()")
        boxes = boxes.split(",")
        for box in boxes:
            box = box.split(" ")
            if box not in boundingboxcord:
                boundingboxcord.extend(box)
    boundboxcord = [float(x) for x in boundingboxcord]
    boundboxns = boundboxcord[::2]
    boundboxew = boundboxcord[1::2]
    southlimit = min(boundboxns)
    northlimit = max(boundboxns)
    eastlimit = max(boundboxew)
    westlimit = min(boundboxew)

    swlimit = "( " + str(southlimit) + ", " + str(westlimit) + " )\n"
    nelimit = "( " + str(northlimit) + ", " + str(eastlimit) + " )\n"

    minboundbox = "\n" + "Minimal Bounding Box = BOX" + swlimit + ", " + nelimit + " \n " 
    
    logfile.write(minboundbox)
    return southlimit, northlimit, eastlimit, westlimit, swlimit, nelimit

def moveGDB(GDBfileName):
    destFolder = "//mnt/public/SFD_Projects/CIF_Pool/Archive/"
    #print "GDBFILENAME = ", GDBfileName
    call(["rm -rf " + GDBfileName ],shell=True)

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
def processFile(GDB_filename, mode):
    logging.info("Here....the file %s"%GDB_filename)
    try:

        #Source file info after clicking OK on dialog box
        submit_time = datetime.now().strftime("%Y%m%d_%H%M_%f")
        print("\n" + "S"*104)
        print("\n\n  GDB Submitted at: " + submit_time + "\n")
        #Config.configure(mode, submit_time)
        Config.configure(mode, submit_time, GDB_filename)        
        importvariables(mode)
        Config.configure_after(GDB_filename, submit_time)
        configure_after_values = configure_after(GDB_filename, submit_time)
        filename = configure_after_values[0]
        Req_ID = configure_after_values[1]
        xmlPath = configure_after_values[2]
        logFilePath = configure_after_values[3]
        print ("  Source Database is " + sourceDatabaseFile + "\n")
        print ("  Req ID is " + Req_ID + "\n")
        print "  Log File Path is: ", logFilePath, "\n"
        logfile = open(logFilePath, "w")
        logfile = open(logFilePath, "a")
        xmlfile = open(xmlPath, "w")
        writexml("BAH",sourceDatabaseFile,xmlPath)
        writeLogEntry(("The GDB full path is:  " + sourceDatabaseFile + "\n"), logfile)
        print "  The source file and path is:  ", sourceDatabaseFile, "\n\n"
        #print "Destination absolute path is: ", destinationDatabaseFile, "\n\n"

        #Connection to Portal for Results
        rconnection = psycopg2.connect(rdbConnectionArgs)
        rconnection.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        rcursor = rconnection.cursor()
        rGIS_DB = "grms" #needs to be in lower case
        rcursor.execute("SELECT MAX(review_num) as HighestPrice FROM cif.cif_results WHERE requirement_id = '" + str(Req_ID) + "'")
        for row in sorted(rcursor):
            if row[0]:
                review_num = row[0] + 1
            else:
                review_num = 1


        rcursor.execute("SELECT user_id as User_ID FROM cif.product WHERE requirement_id = '" + str(Req_ID) + "'")
        for row in sorted(rcursor):
            if row[0]:
                user_id = row[0] 
            else:
                user_id = 0


        #Connect to existing PostgreSQL DB
        connection = psycopg2.connect(dbConnectionArgs)
        connection.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        cursor = connection.cursor()
    
        #check for and remove previous GIS database instances from prior runs
        GIS_DB = "gdb_" + submit_time + "_" #needs to be in lower case
        writeLogEntry(("Establishing / Connecting to postgreSQL DB: " + GIS_DB + "\n"), logfile)
        checkForExistingDB(GIS_DB,cursor)
    
        #create and connection to postgreSQl DB
        cursor.execute("CREATE DATABASE {}".format(GIS_DB))
        connection = psycopg2.connect("dbname={} user={} password={} host={}".format(GIS_DB, dbUser, dbUserPw, dbHost))
        cursor = connection.cursor()
        cursor.execute("CREATE EXTENSION postgis")
        cursor.execute("ALTER TABLE geometry_columns OWNER TO {}".format(dbUser))
        cursor.execute("ALTER TABLE spatial_ref_sys OWNER TO {}".format(dbUser))
        connection.commit()

        #convert GDB to PostgreSQL
        convertStartTime = datetime.now().strftime("%H:%M:%S.%f")
        exportGDBtoPosgreSQL(logfile, sourceDatabaseFile, GIS_DB)
        convertEndTime = datetime.now().strftime("%H:%M:%S.%f")
        elapsedConversionTime = computeElapsedTime( convertStartTime, convertEndTime )
        logfile.write(str("\nPostgreSQL Conversion Time: " + str(elapsedConversionTime) + "\n\n"))
        started_status = "STARTED"

        rcursor.execute("INSERT INTO cif.cif_status(requirement_id, start_time, gdb_name, review_num, status, user_id) VALUES ('" + str(Req_ID) + "', LOCALTIMESTAMP, '" + str(GIS_DB) + "', '" + str(review_num) + "', '" + str(started_status) + "', '" + str(user_id) +"');")

#BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB
        boundingBoxStartTime = datetime.now().strftime("%H:%M:%S.%f")
        logfile.write("\nCreating a Minimum Bounding Box\n")

        boundingbox_values = boundbox(logfile, cursor)
        
        boundingBoxEndTime = datetime.now().strftime("%H:%M:%S.%f")
        elapsedBoundingBoxTime = computeElapsedTime(boundingBoxStartTime, boundingBoxEndTime)


#PCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPCPC
    
        preCheckStartTime = datetime.now().strftime("%H:%M:%S.%f")

        logfile.write(str("\nRelevant Layers to Check: \n\n" + str(relLayers) + "\n\n"))
        """
        #Check for Filter #1
        relfilter1 = [set(filter1) & set(relLayers)]
        if relfilter1:
            relRules.append("1-Illegal Shared Faces")
            appendxml("CIF0001_RC1", "Illegal Shared Face Errors", xmlPath)
            z2.append("CIF0001_RC1")
        
        #Check for Filter #2
        if relLayers:
            relRules.append("2-Duplicates")
            appendxml("CIF0002_RC1", "Duplicate Features", xmlPath)
            z2.append("CIF0002_RC1")
        
        #Check for Filter #3
        relGrdTrans3 = [set(grdtrans3) & set(relLayers)]
        relBldg3 = [set(bldg3) & set(relLayers)]
        if relGrdTrans3:
            if relBldg3:
                relRules.append("3-Ground Trans Int Buildings")
                appendxml("CIF0003_RC1", "Ground Transportation Intersecting Buildings", xmlPath)
                z2.append("CIF0003_RC1")
        
        #Check for Filter #4
        relHydro4 = [set(hydro4) & set(relLayers)]
        relBldg4 = [set(bldg4) & set(relLayers)]
        if relHydro4:
            if relBldg4:
                relRules.append("4-Buildings in Perennial Waters")
                appendxml("CIF0004_RC1", "Building in Perennial Waters", xmlPath)
                z2.append("CIF0004_RC1")
    
        #Check for Filter #5
        relGrdTrans5 = [set(grdtrans5) & set(relLayers)]
        relHydro5 = [set(hydro5) & set(relLayers)]
        if relGrdTrans5:
            if relHydro5:
                relRules.append("5-Ground Trans Int Per Waters")
                appendxml("CIF0005_RC1", "Ground Transportation Intersecting Perennial Waters", xmlPath)
                z2.append("CIF0005_RC1")
        
        #Check for Filter #6
        relGrdTrans6 = [set(filter6) & set(relLayers)]
        if relGrdTrans6:
            relRules.append("6- Mismatch Trans Grnd Curves")
            appendxml("CIF0006_RC1", "Mismatched Transportation Ground Curves", xmlPath)
            z2.append("CIF0006_RC1")
        
        #Check for Filter #7, 8
        relcif7 = [set(filter7) & set(relLayers)]
        if relcif7:
            relRules.append("7,8- Slivers and Overlaps")
            appendxml("CIF0007_RC1", "Slivers and Overlap Slivers", xmlPath)
            z2.append("CIF0007_RC1")
        
        #Check for Filter #10
        if relLayers:
            relRules.append("10- Sharp Curve Finder")
            appendxml("CIF0010_RC1", "Sharp Curve Finder", xmlPath)
            z2.append("CIF0010_RC1")
        
        #Check for Filter #11
        if relLayers:
            relRules.append("11- Line Merge Failure Check")
            appendxml("CIF0011_RC1", "Line Merge Failure Check", xmlPath)
            z2.append("CIF0011_RC1")
        
        #Check for Filter #12
        if relLayers:
            relRules.append("12- Area Merge Failure Check")
            appendxml("CIF0012_RC1", "Area Merge Faulure Check", xmlPath)
            z2.append("CIF0012_RC1")
        
        #Check for Filter #16
        if relLayers:
            relRules.append("16- Null Subattribute Check")
            appendxml("CIF0016_RC1", "Null Subattribute Check", xmlPath)
            z2.append("CIF0016_RC1")
        """
        #Check for Filter #17
        relcif17 = [set(allCrvLayerList) & set(relLayers)]
        if relcif17:
            relRules.append("17- Overshoot & Undershoot Finder")
            appendxml("CIF0017_RC1", "Overshoot & Undershoot Finder", xmlPath)
            z2.append("CIF0017_RC1")
        """
        #Check for Filter #18
        if relLayers:
            relRules.append("18- Feature Level Metadata Check (FLM)")
            appendxml("CIF0018_RC1", "Feature Level Metadata Check (FLM)", xmlPath)
            z2.append("CIF0018_RC1")
        
        #Check for Filter #19
        relcif19 = [set(filter19) & set(relLayers)]
        if relcif19:
            relRules.append("19- Master Width Finder")
            appendxml("CIF0019_RC1", "Master Width Finder", xmlPath)
            z2.append("CIF0019_RC1")
        
        #Check for Filter #20
        relcif20 = [set(filter20) & set(relLayers)]
        if relcif20:
            relRules.append("20- Master Scale Finder")
            appendxml("CIF0020_RC1", "Master Scale Finder", xmlPath)
            z2.append("CIF0020_RC1")
        
        #Check for Filter #22
        if relLayers:
            relRules.append("22- VSN Check")
            appendxml("CIF0022_RC1", "VSN Check", xmlPath)
            z2.append("CIF0022_RC1")
        
        #Check for Filter #25
        relcif25 = [set(filter25) & set(relLayers)]
        if relcif25:
            relRules.append("25- Missing Bridge, Culvert, and Ford Check")
            appendxml("CIF0025_RC1", "Missing Bridge, Culvert, and Ford Check", xmlPath)
            z2.append("CIF0025_RC1")
        
        #Check for Filter #26
        relcif26 = [set(allSrfCrvList) & set(relLayers)]
        if relLayers:
            relRules.append("26- One Degree Check")
            appendxml("CIF0026_RC1", "One Degree Check", xmlPath)
            z2.append("CIF0026_RC1")
        
        #Check for Filter #27
        relcif27 = [set(filter27) & set(relLayers)]
        if relcif27:
            relRules.append("27- LMC Check")
            appendxml("CIF0027_RC1", "LMC Check", xmlPath)
            z2.append("CIF0027_RC1")
        """
        relRules.sort()


        preCheckEndTime = datetime.now().strftime("%H:%M:%S.%f")
        elapsedpreCheckTime = computeElapsedTime( preCheckStartTime, preCheckEndTime )

#RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

        prettyPrintXml(xmlPath)
        logfile.write(str("\nRelevant CIFs to Run: \n\n" + str(relRules) + "\n\n"))
        logfile.write("\nTotal Pre Check Time:   " + str(elapsedpreCheckTime) + "\n\n")
        print "\n"
        print("-"*104 + "\n")    
        print "       Conversion Start Time: ", convertStartTime
        print "         Conversion End Time: ", convertEndTime
        print "                                                      Total Conversion Time:  ", elapsedConversionTime, "\n"    
        print "     Bounding Box Start Time: ", boundingBoxStartTime
        print "       Bounding Box End Time: ", boundingBoxEndTime
        print "                                                      Total Bounding Box Time:", elapsedBoundingBoxTime, "\n"
        print("PC"*52 + "\n")
        print "        Pre Check Start Time: ", preCheckStartTime
        print "          Pre Check End Time: ", preCheckEndTime
        print "                                                      Total Pre Check Time:   ", elapsedpreCheckTime, "\n"
        print ("                                                      " + str(len(relRules)) + "  Relevant CIFs to run\n")
        print ("                                                      " + str(len(relLayers)) + "  Relevant Layers to Check \n\n")
        print("F"*104 + "\n")

#SQLUSQLUSQLUSQLUSQLUSQLUSQLUSQLUSQLUSQLUSQLUSQLUSQLUSQLUSQLUSQLUSQLUSQLUSQLUSQLUSQLUSQLUSQLUSQLUSQLU

        for layer in allSrfLayerList:
            cursor.execute("CREATE TABLE " + layer + "_results_geom (pk serial, cif_title varchar, ogc_fid serial, layer_name varchar, requirement_id text, geom geometry(MultiPolygonZ,4326), PRIMARY KEY (pk));")
        for layer in allCrvLayerList:
            cursor.execute("CREATE TABLE " + layer + "_results_geom (pk serial, cif_title varchar, ogc_fid serial, layer_name varchar, requirement_id text, geom geometry(MultiLineStringZ, 4326), PRIMARY KEY (pk));")
        for layer in allPntLayerList:
            cursor.execute("CREATE TABLE " + layer + "_results_geom (pk serial, cif_title varchar, ogc_fid serial, layer_name varchar, requirement_id text, geom geometry(MultiPointZ, 4326), PRIMARY KEY (pk));")
        cursor.execute("CREATE TABLE expected_missing_polygon_geom (pk serial, cif_title varchar, ogc_fid serial, layer_name varchar, requirement_id text, geom geometry(MultiPolygonZ, 4326), PRIMARY KEY (pk));")
        cursor.execute("CREATE TABLE expected_missing_point_geom (pk serial, cif_title varchar, ogc_fid serial, layer_name varchar, requirement_id text, geom geometry(MultiPointZ, 4326), PRIMARY KEY (pk));")
        cursor.execute("CREATE TABLE expected_missing_line_geom (pk serial, cif_title varchar, ogc_fid serial, layer_name varchar, requirement_id text, geom geometry(MultiLineStringZ, 4326), PRIMARY KEY (pk));")
        connection.commit()
    
    except psycopg2.DatabaseError, e:
        print(str(e))
        writeLogEntry(str(e), logfile)

    return filename, Req_ID, xmlPath, logFilePath, cursor, rcursor, z2, logfile, xmlfile, connection, rconnection, GIS_DB, review_num, boundingbox_values
#NEXTNEXTNEXTNEXTNEXTNEXTNEXTNEXTNEXTNEXTNEXTNEXTNEXTNEXTNEXTNEXTNEXTNEXTNEXTNEXTNEXTNEXTNEXTNEXTNEXT



def executeChecks(filename, Req_ID, xmlPath, logFilePath, GDB_filename, mode, cursor, rcursor, z2, logfile, xmlfile, review_num, boundingbox_values):
    try:
        TotalRunStartTime = datetime.now().strftime("%H:%M:%S.%f")
        print "CheckHere---------------------"
        print "logFilePath = ", logFilePath
        print "logfile = ", logfile
        print "xmlPath = ", xmlPath 
        print "------------------------------"
        #execfile("//home/terrytb/cif/BaseScript.py")
        subprocess.call(['python //mnt/public/SFD_Projects/CIF_Production/BaseScript.py',logFilePath, xmlPath], shell=True)
        TotalRunEndTime = datetime.now().strftime("%H:%M:%S.%f")
        elapsedTotalRunTime = computeElapsedTime( TotalRunStartTime, TotalRunEndTime )
        print ("TOTAL"*20 + "\n")
        print "      Run Start Time: ", TotalRunStartTime
        print "      Run End Time  : ", TotalRunEndTime
        print "                                                 Total Run Time:", elapsedTotalRunTime, "\n"
        print ("TOTAL"*20 + "\n")
        end_status = "FINISHED"

        rcursor.execute("UPDATE cif.cif_status SET check_type = DEFAULT , status = '" + str(end_status) + "' WHERE review_num = " + str(review_num) + " AND requirement_id = '" + Req_ID + "' AND gdb_name = '" + GIS_DB + "';")
        connection.commit()
    
#WMSWMSWMSWMSWMSWMSWMSWMSWMSWMSWMSWMSWMSWMSWMSWMSWMSWMSWMSWMSWMSWMSWMSWMSWMSWMSWMSWMSWMSWMSWMSWMSWMS
        """
        print "\n Updating SQL and Publishing WMS Feeds \n"
        if mode == "production":
            rcursor.execute("SELECT a.submission_date, a.user_id FROM cif.product as a WHERE a.path is '/mnt/public/SFD_Projects/CIF_Pool1/" + filename + ".zip' ORDER BY a.submission_date")
            for row in sorted(rcursor):
                global user_id
                user_id = row[0]
                print user_id
            rcursor.execute("INSERT INTO base.requirements(requirement_id, project_id, program_code, fy_started, domain, cocom, comments, job_status, job_orig_date, revision, mod_alt_date, revised_by) SELECT DISTINCT ON (requirement_id) requirement_id, project_id, program_code, fy_started, domain, cocom, comments, 'Reserve', job_orig_date, max(revision) +1, LOCALTIMESTAMP," + user_id + " FROM public.requirements_view WHERE requirement_id = " + Req_ID + " GROUP BY requirement_id, project_id, program_code, fy_started, domain, cocom, comments, job_status, job_orig_date, revision, mod_alt_date, revised_by Having revision = max(revision);")
        else:
            pass
    
        wmslayerSetup = []
        for layer in allLayerList:
            wmslayerSetup.append(str(layer.lower() + "_results_geom"))
        additional_layers = ["expected_missing_polygon_geom", "expected_missing_line_geom", "expected_missing_point_geom"]
        wmslayerSetup.extend(additional_layers)

        workspace = "cif_results"
        cat = Catalog("http://164.214.197.129:8080/geoserver/rest", "admin", "sfdgeonode")
        wksp = cat.create_workspace(GIS_DB, "http://164.214.197.129:8080/geoserver/" + GIS_DB + "")
        results = cat.get_workspace(GIS_DB)
        ds = cat.create_datastore(GIS_DB + "_ds", GIS_DB)
        ds.connection_parameters.update(host = 'localhost', port = '5432', database = GIS_DB, user = dbUser, passwd = dbUserPw, dbtype = 'postgis', schema = 'public')
        cat.save(ds)
        gd = cat.get_store(GIS_DB + "_ds", workspace)
        cat.save(gd)
        wmslayers = []
        wmsstyles = []
        for layer in wmslayerSetup:
            cursor.execute("SELECT COUNT(ogc_fid) FROM " + layer + ";")
            for row in sorted(cursor):
                if row[0] == 0:
                    continue
                print("WMS feed Created for errors in " + layer + " layer")
                publyr = cat.publish_featuretype(layer, gd, 'EPSG:4326', srs='EPSG:4326')
                wmslayers.append(layer)
                if layer in allSrfLayerList:
                    wmsstyles.append("polygon")
                elif layer in allCrvLayerList:
                    wmsstyles.append("line")
                elif layer in allPntLayerList:
                    wmsstyles.append("point")
                elif layer == "expected_missing_polygon_geom":
                    wmsstyles.append("polygon")
                elif layer == "expected_missing_point_geom":
                    wmsstyles.append("point")
                elif layer == "expected_missing_line_geom":
                    wmsstyles.append("line")
        if wmslayers:
            lg = cat.create_layergroup(GIS_DB + "_results")
            lg.layers = wmslayers
            lg.stls = wmsstyles
            cat.save(lg)
        """
#....................................................................................................

        logfile.close()
        cursor.close()
        connection.close()

    except psycopg2.DatabaseError, e:
        print(str(e))
        writeLogEntry(str(e), logfile)

if __name__=="__main__":
    if len(sys.argv)==2:
        testflg=0
        if sys.argv[1] == "develop":
            mode = "develop"
            GDB_filename = ""
        else:
            GDB_filename = sys.argv[1]
            mode = "production"
        logging.info("About to process file%s"%GDB_filename)
        processFile_values = processFile(GDB_filename, mode)
        filename = processFile_values[0]
        Req_ID = processFile_values[1]
        xmlPath = processFile_values[2]
        logFilePath = processFile_values[3]
        cursor = processFile_values[4]
        rcursor = processFile_values[5]
        z2 = processFile_values[6]
        logfile = processFile_values[7]
        xmlfile = processFile_values[8]
        connection = processFile_values[9]
        rconnection = processFile_values[10]
        GIS_DB = processFile_values[11]
        review_num = processFile_values[12]
        boundingbox_values = processFile_values[13]
        executeChecks(filename, Req_ID, xmlPath, logFilePath, GDB_filename, mode, cursor, rcursor, z2, logfile, xmlfile, review_num, boundingbox_values)
        moveGDB(GDB_filename)
    else:
        testflg=1
        logging.info("No GDB file submitted")
        print "Program requires an input file"
