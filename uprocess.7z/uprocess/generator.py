from geoserver.catalog import Catalog
from geoserver.support import url
import requests
from requests.auth import HTTPBasicAuth
from util.configuration import Configuration
import logging
from util.connection import Connection, Table
from util.logger import Logger
from psycopg2.extensions import AsIs
from django.conf import settings
# from grip.settings import MEDIA_ROOT
import os.path

class GeoJson():
    def __init__(self, job):
        self.config = Configuration()
        log_opts = self.config.mapSection('Log')
        self.log = (Logger(log_opts['name'], log_opts['path'])).getLoggerInstance()
        self.gdb = job
        # self.path = os.path.join(MEDIA_ROOT, str(job.user_id), job.gdb_name)
        self.path = os.path.join(os.getcwd(),'media/temp')

    def getOutput(self):
        layers = ["AeronauticCrv", "AeronauticPnt", "AeronauticSrf", 
                    "AgriculturePnt", "AgricultureSrf", "BoundaryPnt", "BoundarySrf", 
                    "CultureCrv", 'CulturePnt', "CultureSrf", "FacilityPnt", 
                    "FacilitySrf", "HydroAidNavigationPnt", "HydroAidNavigationSrf",
                    "HydrographyCrv", "HydrographyPnt", "HydrographySrf", 
                    "HypsographyCrv", "HypsographyPnt", "IndustryCrv", 
                    "IndustryPnt", "IndustrySrf", "InformationCrv", "InformationPnt", 
                    "InformationSrf", "MilitaryCrv", "MilitaryPnt", "MilitarySrf", 
                    "PhysiographyCrv", "PhysiographyPnt", "PhysiographySrf", 
                    "PortHarbourCrv", "PortHarbourPnt", "PortHarbourSrf", "RecreationCrv", 
                    "RecreationPnt", "RecreationSrf", "SettlementPnt", "SettlementSrf",
                     "StoragePnt", "StorageSrf", "StructureCrv", 
                     "StructurePnt", "StructureSrf", "SubterraneanSrf", 
                     "TransportationGroundCrv", "TransportationGroundPnt",
                      "TransportationGroundSrf", "TransportationWaterCrv", 
                      "TransportationWaterPnt", "TransportationWaterSrf", 
                      "UtilityInfrastructureCrv", "UtilityInfrastructurePnt", 
                      "UtilityInfrastructureSrf", "VegetationCrv", "VegetationPnt", 
                      "VegetationSrf", "MetadataSrf", "ResourceSrf"]
        for i in layers:
            layer = '{layer}_results_geom'.format(layer=i.lower())
            if (Table(self.gdb,layer)).tableExists():
                self.log.info('Geojson Request for {layer}'.format(layer=layer))     
                conn = Connection(self.gdb)  
                conn.create()
                curs = conn.getCursor()
                sqlStr = 'SELECT row_to_json(featcoll)'\
                            'FROM '\
                                '(SELECT \'FeatureCollection\' As type, '\
                                    'array_to_json(array_agg(feat)) As features '\
                                'FROM (SELECT \'Feature\' As type, '\
                                      'ST_AsGeoJSON(tbl.geom)::json As geometry, '\
                                      'row_to_json((SELECT l FROM (SELECT pk, '\
                                        'cif_title, ogc_fid, requirement_id, '\
                                        'layer_name) As l) '\
                                ') As properties '\
                            'FROM %(layer)s As tbl )  As feat '\
                       ')  As featcoll;'
                self.log.debug(curs.mogrify(
                    sqlStr, {'layer':AsIs(layer)}
                )) 
                curs.execute(
                    sqlStr, {'layer':AsIs(layer)}
                )    
                results = str(curs.fetchone()[0]).replace('u\'', '\"').replace('\'', '\"')
                self.log.debug('{layer} Results: {results}'.format(results=results, layer=layer))
                conn.close()
                with open('{path}/{gdb}-{fname}.json'.format(path=self.path, fname=layer, gdb=self.gdb), 'w') as file:
                    file.write(results)
                    # print('****JSON OUTPUT',results)

        return self.path


        

# class PGConnection():
#     def __init__(self, database=None):
#         config = Configuration()
#         opts = config.mapSection('CIF_Database')
#         self.host = opts['host'] 
#         self.port = opts['port']
#         self.user = opts['user']
#         self.passwd = opts['passwd']
#         self.dbtype = opts['dbtype']
#         self.schema = opts['schema']
#         self.database = database
#         self.max_connections = opts['max_connections']
#         self.min_connections = opts['min_connections']
#         self.Max_connection_idle_time = opts['max_connection_idle_time']
#         self.Connection_timeout = opts['connection_timeout']
#         self.fetch_size = opts['fetch_size']

#     def getParameters(self):
#         db = {}
#         db['host'] = self.host
#         db['port'] = self.port
#         db['user'] = self.user
#         db['passwd'] = self.passwd
#         db['dbtype'] = self.dbtype
#         db['schema'] = self.schema
#         db['database'] = self.database
#         db['max connections'] = self.max_connections
#         db['min connections'] = self.min_connections
#         db['Max connection idle time'] = self.Max_connection_idle_time
#         db['Connection timeout'] = self.Connection_timeout
#         db['fetch size'] = self.fetch_size
#         return db

# class Geoserver(object):
#     def __init__(self, database, name):
#         config = Configuration()
#         geo_opts = config.mapSection('Geoserver')
#         log_opts = config.mapSection('Log')
#         self.name = name
#         self.database = database
#         self.base_url = geo_opts['url']#'http://localhost:8080/geoserver/'
#         self.path = config.mapSection('Output')['geoserver']
#         self.log = (Logger(log_opts['name'], log_opts['path'])).getLoggerInstance()
#         self.user = geo_opts['user']
#         self.passwd = geo_opts['passwd']

#         self.params = (PGConnection(database)).getParameters()   
#         #DEVNOTE: Verify user/pass is safe
#         self.cat = Catalog(self.getRestUrl(),  self.user , self.passwd)
#         self.ws = self.createWorkspace()
#         self.ds = self.createDataStore()

#     def findLayers(self, search):
#         availFeatureTypes = self.ds.get_resources(available=True)
#         return [featureType for featureType 
#             in availFeatureTypes 
#                 if featureType.find(search)>0]

#     def deleteWorkspace(self):
#         self.cat.delete(self.cat.get_workspace(self.name), recurse=True)

#     def createWorkspace(self):
#         namespace_url = ('{base}{name}').format(base=self.base_url,name=self.name)
#         return self.cat.create_workspace(self.name, namespace_url)

#     def createDataStore(self):
#         ds = self.cat.create_datastore(self.database, self.ws.name)
#         ds.connection_parameters.update(self.params)
#         self.cat.save(ds)
#         return ds

#     def getWfsUrl(self, layer):
#         return ('{url}{name}/ows?service=WFS&version=1.0.0&'\
#                     'request=GetFeature&typename={name}:{layer}&outputFormat='\
#                         'json').format(url=self.base_url,name=self.name,layer=layer)
#     def getRestUrl(self):
#         return ('{base}{rest}').format(base=self.base_url,rest='rest/')

#     def getLayer(self,layer):
#         self.log.info('Accessing Geoserver FeatureType {layer}'.format(layer=layer))
#         featureType = self.cat.publish_featuretype(layer, self.ds, 'EPSG:4326')
#         wfs_url = self.getWfsUrl(layer)

#         #DEVNOTE: Verify user/pass is safe
#         response = requests.get(wfs_url, auth=HTTPBasicAuth(self.user, self.passwd))
#         output =  response.content
#         self.log.info('FeatureType Content is {output}'.format(output=output))

#         with open('{path}/{gdb}-{fname}.json'.format(path=self.path, fname=layer, gdb=self.database), 'w') as file:
#             file.write(output)
#         return output

#     def getAllResultLayers(self):
#         resultList = self.findLayers('_results_geom')
#         output = []
#         for layer in resultList: 
#             out = self.getLayer(layer)
#             output.append(out)
#             self.log.info(out)

if __name__ == "__main__":
    #This section is for POSTGIS GeoJson 
    layers = ["AeronauticCrv", "AeronauticPnt", "AeronauticSrf", 
    "AgriculturePnt", "AgricultureSrf", "BoundaryPnt", "BoundarySrf", 
    "CultureCrv", 'CulturePnt', "CultureSrf", "FacilityPnt", 
    "FacilitySrf", "HydroAidNavigationPnt", "HydroAidNavigationSrf",
    "HydrographyCrv", "HydrographyPnt", "HydrographySrf", 
    "HypsographyCrv", "HypsographyPnt", "IndustryCrv", 
    "IndustryPnt", "IndustrySrf", "InformationCrv", "InformationPnt", 
    "InformationSrf", "MilitaryCrv", "MilitaryPnt", "MilitarySrf", 
    "PhysiographyCrv", "PhysiographyPnt", "PhysiographySrf", 
    "PortHarbourCrv", "PortHarbourPnt", "PortHarbourSrf", "RecreationCrv", 
    "RecreationPnt", "RecreationSrf", "SettlementPnt", "SettlementSrf",
     "StoragePnt", "StorageSrf", "StructureCrv", 
     "StructurePnt", "StructureSrf", "SubterraneanSrf", 
     "TransportationGroundCrv", "TransportationGroundPnt",
      "TransportationGroundSrf", "TransportationWaterCrv", 
      "TransportationWaterPnt", "TransportationWaterSrf", 
      "UtilityInfrastructureCrv", "UtilityInfrastructurePnt", 
      "UtilityInfrastructureSrf", "VegetationCrv", "VegetationPnt", 
      "VegetationSrf", "MetadataSrf", "ResourceSrf"]
    geojson = GeoJson('AFG_Test')
    for i in layers:
        layer = '{layer}_results_geom'.format(layer=i.lower())
        geojson.getOutput(layer)

    #This section is for Geoserver GeoJson 
    # g = Geoserver('gdb_20170405_0655_166457_','name')
    # g.getAllResultLayers()
    # g.deleteWorkspace()
