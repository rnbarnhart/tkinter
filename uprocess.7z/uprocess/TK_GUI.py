#!/usr/bin/python
#try:
    #python 2
import Tkinter as tk
from Tkinter import *
import tkMessageBox
import tkFileDialog
from tkFileDialog import askdirectory, askopenfilename
import getpass, zipfile, os
from ScrolledText import *
from CIF_Mod import CIF
from GRIP import initialize
#except ImportError:
#    # for Python 3
#    from tkinter import *
#    import tkinter as tk
#    import tkiner.scrolledtext as tksk
#    from tkinter.filedialog import *

class CIFUI( tk.Frame ):
    def __init__(self, *args, **kwargs):
        tk.Frame.__init__(self, *args, **kwargs)

        #screen dimensions
        height=600
        width=800
        #center screen
        screen_width = self.master.winfo_screenwidth()
        screen_height = self.master.winfo_screenheight()
        x = (screen_width/2) - (width/2)
        y = (screen_height/2) - (height/2)
        self.master.geometry('%dx%d+%d+%d'%(width, height, x, y))        
        #screen title
        self.master.title( "Run CIF Checks" )
        self.form1()
        self.menu()

    def menu(self):
        self.master.attributes('-topmost', False)
        self.master.option_add('*tearOff','FALSE')
        self.menubar = tk.Menu(self.master)
        self.menu_file = tk.Menu(self.menubar)
        self.menu_help = tk.Menu(self.menubar)
        
        self.menu_file.add_command(label='Exit', command=self.on_quit)
        self.menubar.add_cascade(menu=self.menu_file, label='File')

        self.menubar.add_cascade(menu=self.menu_help, label='Help')
        self.menu_help.add_command(label='About', command=self.on_about)

        self.master.config(men=self.menubar)
        
    def on_quit(self):
        self.master.destroy()

    def on_about(self):
        win = tk.Tk()
        height=100
        width=200
        screen_width = win.winfo_screenwidth()
        screen_height = win.winfo_screenheight()
        x = (screen_width/2) - (width/2)
        y = (screen_height/2) - (height/2)
        win.geometry('%dx%d+%d+%d'%(width, height, x, y))
        win.wm_title('About')
        winlm = tk.Label(win, text='uProcess 1.0', anchor='center', font='bold')
        winlm.place(x=100, y=30, anchor='center')
        winb1 = tk.Button(win, text='ok', command=win.destroy)
        winb1.place(x=100,y=60, anchor='center')

    def run_history(self):
        win = tk.Tk()
        height=100
        width=800
        screen_width = win.winfo_screenwidth()
        screen_height = win.winfo_screenheight()
        x = (screen_width/2) - (width/2)
        y = (screen_height/2) - (height/2)
        win.geometry('%dx%d+%d+%d'%(width, height, x, y))
        win.wm_title('Run History')
        winlm = tk.Label(win, text='Run History', anchor='center', font='bold')
        winlm.place(x=400, y=30, anchor='center')
        winb1 = tk.Button(win, text='ok', command=win.destroy)
        winb1.place(x=400,y=70, anchor='center')

    def run_config(self):
        win = tk.Tk()
        height=200
        width=500
        screen_width = win.winfo_screenwidth()
        screen_height = win.winfo_screenheight()
        x = (screen_width/2) - (width/2)
        y = (screen_height/2) - (height/2)
        win.geometry('%dx%d+%d+%d'%(width, height, x, y))
        win.wm_title('Configuration')
        winlm = tk.Label(win, text='User ID', width=10)
        winlm.grid(row=1, column=0, sticky='w')
        winsv = StringVar(win, value='John Doe')
        winle = tk.Entry(win, width=40, textvariable=winsv)
        winle.grid(row=1, column=1, sticky='e') 
        winb1 = tk.Button(win, text='ok', command=win.destroy)
        winb1.place(x=width/2,y=100, anchor='center')

    def form1(self):
        # Left Side of Screen
        
        ls0 = tk.LabelFrame(self.master, text="Project Info", padx=5, pady=5, width=50)
        ls0.grid(row=2, column=0, columnspan=5, sticky='e', padx=5, pady=0, ipadx=0, ipady=0)
       
        l0 = tk.Label(ls0, text="Project ID", width=10)
        l0.grid(row=1, column=0, sticky='w')
        l1v = tk.StringVar(ls0, value='12345')  
        l1 = tk.Entry(ls0, width=30, textvariable=l1v)
        l1.grid(row=1, column=1, sticky='w')
        l2 = tk.Label(ls0, text="User Name", width=10)
        l2.grid(row=2, column=0, sticky='w')
        l1vv = tk.StringVar(ls0, value=str(getpass.getuser()))  
        l3 = tk.Entry(ls0, width=30, textvariable=l1vv)
        l3.configure(state = 'disabled')                                # added line to make username disabled
        l3.grid(row=2, column=1, sticky='w')

        # Right Side of Screen

        right0 = tk.LabelFrame(self.master, text="Run Info", padx=5, pady=5, width=50, height=10)
        right0.grid(row=2, column=6, columnspan=10, sticky='w', padx=5, pady=5, ipadx=0, ipady=0)
        b1 = tk.Button(right0, text="History", command=self.run_history)
        b1.grid(row=1, column=0, sticky='w', padx=5, pady=5, ipadx=5, ipady=0)
        b2 = tk.Button(right0, text="Configuration", command=self.run_config)
        b2.grid(row=1, column=6, sticky='e', padx=5, pady=5, ipadx=5, ipady=0)
        
        
        # Center of screen
        
        def btn1():
        #   filelocation = tkFileDialog.askdirectory(initialdir = "/Home:", title = "Select GDB")
            filelocation = tkFileDialog.askopenfilename(initialdir = "/Home:", title = "Select GDB Zip")
            txt.set(filelocation)

        ## Label and browse set up to input GDB
        lbl = tk.LabelFrame(self.master, text = "Parameters", padx=5, pady=5, width=108)
        lbl.grid(row = 3, column = 0, columnspan=10, sticky='w', padx=5, pady=10, ipadx=0, ipady=0)
        lbl1 = tk.Label(lbl, text = "Select GDB to Load", padx=5, pady=5)
        lbl1.grid(row = 1, column = 0, columnspan=2)
        txt = tk.StringVar()
        text1 = tk.Entry(lbl, textvariable = txt, width = 86)
        text1.grid(row = 2, column = 0)
        button1 = tk.Button(lbl, text = " Browse ", command = btn1)
        button1.grid(row = 2, column = 1)


        ## Label for dropdown schema selection
        lbl.schema = tk.LabelFrame(lbl, text = "Select Schema", labelanchor='n', padx=5, pady=5)
        lbl.schema.grid(row = 3, column = 0, columnspan=2, padx=5, pady=10, ipadx=0, ipady=0)
        tkvar = StringVar()
        ## Dictionary with options for dropdown schema selection
        choices = {'   ','TDS','TFDM','MGCP','AFD','SAC'}
        tkvar.set('   ') # set the default option
        popupMenu = OptionMenu(lbl.schema, tkvar, *choices)
        popupMenu.grid(row = 1, column = 0, columnspan=2, padx=10, pady=5)

        
        def btn2():
            initialize(txt.get())
            # process_scripts = {CIF01:['CIF01','CIF01.py'], CIF01:['CIF02','CIF01.py'], CIF03:['CIF03','CIF03.py'], CIF04:['CIF04','CIF04.py'], CIF05:['CIF05','CIF05.py'],
            #                    CIF06:['CIF06','CIF06.py'], CIF07:['CIF07','CIF07.py'], CIF08:['CIF08','CIF08.py'], CIF09:['CIF09','CIF09.py'], CIF10:['CIF10','CIF10.py'],
            #                    CIF11:['CIF11','CIF11.py'], CIF12:['CIF12','CIF12.py'], CIF13:['CIF13','CIF13.py'], CIF14:['CIF14','CIF14.py'], CIF15:['CIF15','CIF15.py'], 
            #                    CIF16:['CIF16','CIF16.py'], CIF17:['CIF17','CIF17.py'], CIF18:['CIF18','CIF18.py'], CIF19:['CIF19','CIF19.py'], CIF20:['CIF20','CIF20.py'], 
            #                    CIF21:['CIF21','CIF21.py'], CIF22:['CIF22','CIF22.py'], CIF23:['CIF23','CIF23.py'], CIF24:['CIF24','CIF24.py'], CIF25:['CIF25','CIF25.py'], 
            #                    CIF26:['CIF26','CIF26.py'], CIF27:['CIF27','CIF27.py'], CIF28:['CIF28','CIF28.py'], CIF29:['CIF29','CIF29.py'], CIF30:['CIF30','CIF30.py']}

            # run_script = tkMessageBox.askyesno('Run Checks?', 'Would you like to run checks on ' + os.path.basename(txt.get()[0:-4])) 
            # if run_script == True:
            #     zip_file = zipfile.ZipFile(txt.get(),'r')
            #     zip_file.extractall(os.path.dirname(txt.get()))
            #     textarray.insert(END, 'Unzipped ' + os.path.basename(txt.get()), 'name')
            #     schema = tkvar.get()
            #     for chks in checks.get(schema):
            #         textarray.insert(END, '\nRunning ' + str(process_scripts.get(chks)[0]) + ' checks', 'cifs')
            #         startfile = process_scripts.get(chks)[1]
            #         print startfile

            #     textarray.insert(END, '\n\n----Completed processing----', 'name')
            # else:
            #     print 'Cancelled'


        def btn3():
            root.destroy()

        def change_dropdown(*args):
            chks = checks.get('   ')
            for chk in chks:
                chk.deselect()
            dropvar = tkvar.get()
            if dropvar != '   ':
        #    for index, values in enumerate()
                chks = checks.get(dropvar)
                for chk in chks:
                    chk.select()


        # Label and new data window frame for checkboxes
        lbl.cifchecks = tk.LabelFrame(lbl, text="Select CIF Checks", labelanchor='n', padx=5, pady=5, width=50)
        lbl.cifchecks.grid(row=5, column=0, columnspan=8, padx=5, pady=5, ipadx=0, ipady=0)
        ## Set variable checkboxes
        CIF01 = IntVar()
        CIF01 = Checkbutton(lbl.cifchecks, variable = CIF01, text = " CIF01")
        CIF01.grid(row = 3, column = 0)
        CIF02 = IntVar()
        CIF02 = Checkbutton(lbl.cifchecks, variable = CIF02, text = " CIF02")
        CIF02.grid(row = 3, column = 1)
        CIF03 = IntVar()
        CIF03 = Checkbutton(lbl.cifchecks, variable = CIF03, text = " CIF03")
        CIF03.grid(row = 3, column = 2)
        CIF04 = IntVar()
        CIF04 = Checkbutton(lbl.cifchecks, variable = CIF04, text = " CIF04")
        CIF04.grid(row = 3, column = 3)
        CIF05 = IntVar()
        CIF05 = Checkbutton(lbl.cifchecks, variable = CIF05, text = " CIF05")
        CIF05.grid(row = 3, column = 4)
        CIF06 = IntVar()
        CIF06 = Checkbutton(lbl.cifchecks, variable = CIF06, text = " CIF06")
        CIF06.grid(row = 3, column = 5)
        CIF07 = IntVar()
        CIF07 = Checkbutton(lbl.cifchecks, variable = CIF07, text = " CIF07")
        CIF07.grid(row = 3, column = 6)
        CIF08 = IntVar()
        CIF08 = Checkbutton(lbl.cifchecks, variable = CIF08, text = " CIF08")
        CIF08.grid(row = 3, column = 7)
        CIF09 = IntVar()
        CIF09 = Checkbutton(lbl.cifchecks, variable = CIF09, text = " CIF09")
        CIF09.grid(row = 3, column = 8)
        CIF10 = IntVar()
        CIF10 = Checkbutton(lbl.cifchecks, variable = CIF10, text = " CIF10")
        CIF10.grid(row = 3, column = 9)
        CIF11 = IntVar()
        CIF11 = Checkbutton(lbl.cifchecks, variable = CIF11, text = " CIF11")
        CIF11.grid(row = 4, column = 0)
        CIF12 = IntVar()
        CIF12 = Checkbutton(lbl.cifchecks, variable = CIF12, text = " CIF12")
        CIF12.grid(row = 4, column = 1)
        CIF13 = IntVar()
        CIF13 = Checkbutton(lbl.cifchecks, variable = CIF13, text = " CIF13")
        CIF13.grid(row = 4, column = 2)
        CIF14 = IntVar()
        CIF14 = Checkbutton(lbl.cifchecks, variable = CIF14, text = " CIF14")
        CIF14.grid(row = 4, column = 3)
        CIF15 = IntVar()
        CIF15 = Checkbutton(lbl.cifchecks, variable = CIF15, text = " CIF15")
        CIF15.grid(row = 4, column = 4)
        CIF16 = IntVar()
        CIF16 = Checkbutton(lbl.cifchecks, variable = CIF16, text = " CIF16")
        CIF16.grid(row = 4, column = 5)
        CIF17 = IntVar()
        CIF17 = Checkbutton(lbl.cifchecks, variable = CIF17, text = " CIF17")
        CIF17.grid(row = 4, column = 6)
        CIF18 = IntVar()
        CIF18 = Checkbutton(lbl.cifchecks, variable = CIF18, text = " CIF18")
        CIF18.grid(row = 4, column = 7)
        CIF19 = IntVar()
        CIF19 = Checkbutton(lbl.cifchecks, variable = CIF19, text = " CIF19")
        CIF19.grid(row = 4, column = 8)
        CIF20 = IntVar()
        CIF20 = Checkbutton(lbl.cifchecks, variable = CIF20, text = " CIF20")
        CIF20.grid(row = 4, column = 9)
        CIF21 = IntVar()
        CIF21 = Checkbutton(lbl.cifchecks, variable = CIF21, text = " CIF21")
        CIF21.grid(row = 5, column = 0)
        CIF22 = IntVar()
        CIF22 = Checkbutton(lbl.cifchecks, variable = CIF22, text = " CIF22")
        CIF22.grid(row = 5, column = 1)
        CIF23 = IntVar()
        CIF23 = Checkbutton(lbl.cifchecks, variable = CIF23, text = " CIF23")
        CIF23.grid(row = 5, column = 2)
        CIF24 = IntVar()
        CIF24 = Checkbutton(lbl.cifchecks, variable = CIF24, text = " CIF24")
        CIF24.grid(row = 5, column = 3)
        CIF25 = IntVar()
        CIF25 = Checkbutton(lbl.cifchecks, variable = CIF25, text = " CIF25")
        CIF25.grid(row = 5, column = 4)
        CIF26 = IntVar()
        CIF26 = Checkbutton(lbl.cifchecks, variable = CIF26, text = " CIF26")
        CIF26.grid(row = 5, column = 5)
        CIF27 = IntVar()
        CIF27 = Checkbutton(lbl.cifchecks, variable = CIF27, text = " CIF27")
        CIF27.grid(row = 5, column = 6)
        CIF28 = IntVar()
        CIF28 = Checkbutton(lbl.cifchecks, variable = CIF28, text = " CIF28")
        CIF28.grid(row = 5, column = 7)
        CIF29 = IntVar()
        CIF29 = Checkbutton(lbl.cifchecks, variable = CIF29, text = " CIF29")
        CIF29.grid(row = 5, column = 8)
        CIF30 = IntVar()
        CIF30 = Checkbutton(lbl.cifchecks, variable = CIF30, text = " CIF30")
        CIF30.grid(row = 5, column = 9)


        ## On change of dropdown value
        checks = {'   ':[CIF01, CIF02, CIF03, CIF04, CIF05, CIF06, CIF07, CIF08, CIF09, CIF10,
                         CIF11, CIF12, CIF13, CIF14, CIF15, CIF16, CIF17, CIF18, CIF19, CIF20, 
                         CIF21, CIF22, CIF23, CIF24, CIF25, CIF26, CIF27, CIF28, CIF29, CIF30],
                  'TDS':[CIF01, CIF02, CIF03, CIF04, CIF05, CIF06, CIF07, CIF08, CIF09, CIF10,
                         CIF11, CIF12, CIF13, CIF14, CIF15, CIF16, CIF17, CIF18, CIF19, CIF20, 
                         CIF21, CIF22, CIF23, CIF24, CIF25, CIF26, CIF27, CIF28, CIF29, CIF30],
                  'TFDM':[CIF02, CIF03, CIF04, CIF05, CIF07, CIF08, CIF09, CIF10,
                         CIF12, CIF13, CIF14, CIF15, CIF17, CIF18, CIF19, CIF20, 
                         CIF22, CIF23, CIF24, CIF25, CIF27, CIF28, CIF29, CIF30],
                  'MGCP':[CIF11, CIF12, CIF13, CIF14, CIF15, CIF16, CIF17, CIF18, CIF19, CIF20],
                  'AFD':[CIF21, CIF22, CIF23, CIF24, CIF25, CIF26, CIF27, CIF28, CIF29, CIF30],
                  'SAC':[CIF10, CIF20, CIF30]}


         ## Link function to change dropdown
        tkvar.trace('w', change_dropdown)


        ## User group predetermined checks
        user_dict = {'barnharn':'AFD', 'terrytb':'MGCP', 'chapmaca':'TFDM', 'tacketmt':'TDS'}
        user_nam = str(getpass.getuser())
        if user_nam in user_dict:
            user_pref = user_dict.get(user_nam)
            tkvar.set(user_pref)
            for chks in checks.get(user_pref):
                chks.select()
        else:
            print "User does not belong to a group"


        button2 = tk.Button(lbl, text = " Run CIF checks ", command = btn2)
        button2.grid(row = 10, column = 0, columnspan=2, pady = 5)


        button3 = tk.Button(lbl, text = " Close Window ", command = btn3)
        button3.grid(row = 11, column = 0, columnspan=2, pady = 5)

        lsm1 = tk.LabelFrame(self.master, text="Processing Info", padx=5, pady=5, width=108, height=10)
        lsm1.grid(row=8, column=0, columnspan=10, sticky='e', padx=5, pady=0, ipadx=0, ipady=0)
        textarray = ScrolledText(lsm1, width = 108, height = 7)
        textarray.grid(row = 0, column = 0, pady = 5)
        # xscrollbar = tk.Scrollbar(lsm1, orient=HORIZONTAL)
        # xscrollbar.grid(row=1, column=0, sticky='w')
        # yscrollbar = tk.Scrollbar(lsm1, orient=VERTICAL)
        # yscrollbar.grid(row=0, column=1)
        # text = Text(lsm1, wrap=NONE, 
        #             xscrollcommand=xscrollbar.set, 
        #             yscrollcommand=yscrollbar.set,
        #             width=110,
        #             height=5)
        # text.grid(row=0, column=0, sticky=W, columnspan=10)
        # xscrollbar.config(command=text.xview)
        # yscrollbar.config(command=text.yview)
        
        # Code for Python 3.6+
        #lsm0a = tkst.ScrolledText(lsm1, width=90, height=10)
        #lsm0a.grid(row=10, column=0, sticky='w')

        # Bottom Buttons
        
def main():
    root = tk.Tk()
    view = CIFUI(root)
    #view.pack(side="top", fill="both")
    root.mainloop()   

if __name__ == "__main__":
   main()


