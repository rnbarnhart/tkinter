import logging, zipfile, os

#Replace os function

def unzipfile(zipFilePathName):
    logging.info('Unzipping file.')
    zip_ref = zipfile.ZipFile(zipFilePathName,'r')
    zip_ref.extractall(os.path.dirname(zipFilePathName))
    for x in zip_ref.infolist():
        fname = x.filename
        break;
    zip_ref.close
    logging.info('File unzipped.')
    return fname

    