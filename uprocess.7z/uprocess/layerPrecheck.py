#!/usr/bin/python2.7

#######################################################################################################
##
##   Authors: William "Alex" Jones, Michael Tackett, Theodore Terry, George Jarvis
##
##   Date: 20 Jan 2017
##
##   Written in Python 2.7.5, SQL portions are PostgreSQL 9.3 with PostGIS
##
##   Overall Python Dependencies (imports): json, xml, subprocess, psycopg2, lxml, logging, multiprocessing,
##   signal, ConfigParser, glob, Tkinter, tkFileDialog, traceback, tkMessageBox, shlex, errno, Config,
##   Publish, os, sys, datetime, time
##
##   File name: CIF0002_RC1.py
##
##   Description: 2-Duplicate Features
##   Identify any feature that is duplicated in geometry, feature type and attribution by
##   another feature with different UFI (if present).
##
#######################################################################################################
import sys 
from psycopg2.extensions import AsIs
from multiprocessing import Process, Queue, Pool, TimeoutError
import itertools
from util.connection import Connection
from util.metrics import Timer
from util.results import Results
from util.logger import Logger
from util.filters import FilterLayer
from util.layer import Layer
from CIF_Mod import CIF

class Precheck(CIF):
    def __init__(self, requirement_id, gdb, reviewNumber, path = None):
        '''
        This function controls the initialization of a CIF instance

        :type self: instance variable
        :param self: makes it absolutely clear that an instance variable is used syntactically

        :type requirement_id: string
        :param requirement_id: vendor-generated alphanumeric ID
        
        :type gdb: string
        :param gdb: GDB file to be analyzed

        :type reviewNumber: integer
        :param reviewNumber: current iteration of analyzing GDB
        

        :type path: string
        :param path: path to GDB
        '''
    
        CIF.__init__(self, requirement_id, gdb, reviewNumber,path)
        self.title = "-1 - Precheck"
        self.id = -1
        self.fl = FilterLayer()
        self.layerDict = {}

    def runPrecheck(self, layer):
        '''
        This function depends on the existence of an ESRI GDB file which has already been converted over to a PostgreSQl database.  This function makes a connection to the PostgreSQl server for said converted GDB.  This check looks for any duplicate feature within the same GDB layer.  This CIF check correlates to an internal memorandum discussing the "Big 6" checks.

        :type self: instance method
        :param self: makes it absolutely clear that an instance method is used syntactically

        :type layer: string
        :param layer: name of current GDB layer to be analyzed for duplicate features

        :type layerDict: string
        :param layerDict: name of the dictionary to be filled by the results
        
        :type sql: string
        :param sql: local variable containing the explicit PostGIS SQL query for the current GDB layer to find features satisfying the current CIF check
        '''
    
        conn = Connection(self.gdb) 
        self.log.info('Checking Layer Requirements in {layer}'.format(layer=layer))       
        self.log.debug('Connection to Database created.')
        conn.create()
        curs = conn.getCursor()

        #Devnote: ST_Equals will return false for invalid geometries therefore no ogc_fid filtering is required. 
        #           Additionally, the order of the points doesnt matter - it is the equivalent of 
        #           ST_Within(a,b) AND ST_Within(b,a)

        # Removed 'ST_MakeValid from the ST_IsValid call to only count those features that are valid.'
        sql = 'SELECT COUNT(ogc_fid) FROM %(layer)s WHERE ST_IsValid(geom)'
                
        self.log.debug(curs.mogrify(
            sql, {
                'layer':AsIs(layer),
            }
        )) 
        curs.execute(
            sql, {
                'layer':AsIs(layer),
            }        
        )    
        self.log.info("{errors} errors found in {layer}".format(errors=curs.rowcount, layer=layer))
        results = curs.fetchone()
        layerTest = layer
        counting = results[0]
        self.layerDict[layerTest] = int(counting)
        conn.close()

        # DEVELOP: Change connection to applicable db

        connTwo = Connection('cifquerytest')
        connTwo.create()
        cursTwo = connTwo.getCursor()
        if results:
        # self.publishResult(tuple(results), layer)

            sqlOne = 'UPDATE results.lyr_featurecount SET '\
            '%(layer)s = %(counting)s '\
            'WHERE review_num = %(review_num)s '\
                'AND gdb_name = %(gdb_name)s'
                
        self.log.debug(cursTwo.mogrify(
            sqlOne, {
                'layer':AsIs(layer),
                'counting':counting, 
                'review_num':self.reviewNumber, 
                'gdb_name':self.gdb
            }
        )) 
        cursTwo.execute(
            sqlOne, {
                'layer':AsIs(layer),
                'counting':counting, 
                'review_num':self.reviewNumber, 
                'gdb_name':self.gdb            }        
        )

        connTwo.close()
        return results, self.layerDict
        
    def multi(self, isEnabled=False):
        '''
        This function is not currently implemented as intended.  When implemented this function will kick off up to 8 independent processes in order or minimize analysis time for the current GDB file.

        :type self: instance method
        :param self: makes it absolutely clear that an instance method is used syntactically

        :type isEnabled: boolean
        :param isEnabled: temporary variable to remind developers that multi-processing is currently not working and needs to be resolved for full production use

        :type layerList: list
        :param layerList: python list of strings containing the names of all GDB layers to be inspected for the current CIF check
        '''

        # DEVELOP: Change below connection to appropriate db

        self.timer.startTimer()

        connTwo = Connection('cifquerytest')
        connTwo.create()
        cursTwo = connTwo.getCursor()
        query = 'INSERT INTO results.lyr_featurecount (requirement_id, gdb_name, review_num)'\
                ' VALUES (%(requirement_id)s, %(gdb_name)s, %(review_num)s);'
        self.log.debug(cursTwo.mogrify(query,
            {
            'requirement_id':self.requirement_id,
            'gdb_name':self.gdb,
            'review_num':self.reviewNumber,
            }))
        
        cursTwo.execute(query,
            {
            'requirement_id':self.requirement_id,
            'gdb_name':self.gdb,
            'review_num':self.reviewNumber,
            })
        connTwo.close()

        layerList = self.fl.preCheckTest
        cifLib = self.fl.cifLib

        if isEnabled:
            raise ValueError('MultiProcessing is not enabled at this time')
        else:
            for i in layerList:
                self.runPrecheck(i)

        allLayerCount = sum(self.layerDict.values())
        featureCount = {}
        #        print self.layerDict
        for lyr in cifLib:
            if len(cifLib[lyr]) == 59:
                featureCount[lyr] = allLayerCount
            else:
                w = 0
                for i in cifLib[lyr]:
                    s = []
                    w += self.layerDict[i]
                featureCount[lyr] = w

        print featureCount

        self.timer.stopTimer()
        #(Results(self.log, Connection(self.appDbName))).insertTiming(self.id, self.reviewNumber, self.gdb, self.timer.getRunTime())
        self.log.info('Total Run Time for Precheck: {time}'.format(time=self.timer.getRunTime()))
                
if __name__ == "__main__":
    '''
    Devnote: This is for integration into the existing structure. 
        Eventually, remove this conditional and only use this __main__ for testing/other relevant logic .  
    '''
    if len(sys.argv) >= 6:
        path = str(sys.argv[0])
        requirement_id = str(sys.argv[1])
        gdb_name = str(sys.argv[4])
        review_num = int(sys.argv[5])
    else:
        requirement_id = 'TestOne'
        gdb_name = 'AFG_Test'
        path = 'test.log'
        review_num = '102'
    cif = Precheck(requirement_id,gdb_name,review_num,invalidFeatures,path)
    cif.multi(False)
