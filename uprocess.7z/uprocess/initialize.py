import unzipper
from django.utils import timezone
from gdbtodb import gdbTodb
from util.connection import Connection
from layerPrecheck import Precheck
from django.db import models
from grip.settings import MEDIA_ROOT
# from precheck.models import Job
import os, shutil
import applicableChecks
from precheck.signals import precheck_done


def initialize(job):

    #job = Job.objects.filter(jobID = jobId).filter(rev = rev)
    unzipped_file = unzipper.unzipfile(job.original_file)
    unzipped_filepath = MEDIA_ROOT + "/temp/" + unzipped_file

    submit_time = timezone.now().strftime("%Y%m%d_%H%M_%f")
    GIS_DB = "gdb_" + submit_time + "_"

    pg_connection = Connection('postgres')
    pg_connection.create()

    converter = gdbTodb()
    converter.createDB(GIS_DB,pg_connection)
    converter.exportGDBtoPosgreSQL(unzipped_filepath, GIS_DB)
    job.gdb_name = GIS_DB

    precheck = Precheck(job.jobID,GIS_DB,job.rev)
    precheck.multi()

    job.applicable_checks = ", ".join(applicableChecks.getApplicableChecks(job.jobID,job.rev))

    job.save()

    shutil.rmtree(unzipped_filepath)
    os.remove(job.original_file.name)

    return job

