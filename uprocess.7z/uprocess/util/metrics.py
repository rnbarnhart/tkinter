from datetime import datetime

class Timer():
    def __init__(self):
        self.start = None
        self.stop = None
        self.elapsed = None
        self.format = "%y:%j:%H:%M:%S.%f"
        self.reportFormat = "%H:%M%S.%f"

    def startTimer(self):
        self.start = datetime.now().strftime(self.format)
    
    def stopTimer(self):
        self.stop = datetime.now().strftime(self.format)
    
    def getStartTime(self):
        return (self.start.strftime(self.reportFormat))

    def getStopTime(self):
        return (self.stop.strftime(self.reportFormat))
        
    def getRunTime(self):
        return (datetime.strptime(self.stop,self.format) - datetime.strptime(self.start, self.format)).total_seconds()

