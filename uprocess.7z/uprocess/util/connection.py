#!/usr/bin/python2.7
#DEVNOTE: future import must happen at top of file. 
from __future__ import generators

import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT, AsIs
from configuration import Configuration
from logger import Logger

'''
DEVNOTE: move initialization from hardcode to a configuration param.
'''
class Connection(object):
    def __init__(self, name):
        self.config = Configuration()
        log_opts = self.config.mapSection('Log')
        if name == self.config.mapSection('Database')['name']:
            db_opts = self.config.mapSection('Database')
        else:
            db_opts = self.config.mapSection('CIF_Database')
        self.log = (Logger(log_opts['name'], log_opts['path'])).getLoggerInstance()
        self.name= name
        self.user=db_opts['user']
        self.password=db_opts['passwd']
        self.host=db_opts['host']
        self.connection = None
        self.cursor = None

    def create(self):
        try:
            self.connection = psycopg2.connect('dbname={} user={} password={} '\
                ' host={}'.format(self.name, self.user, self.password, self.host))
            self.connection.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
            self.log.debug('Connection to Database created.')

            return True
        except psycopg2.DatabaseError, e:
            self.log.error(e)

    def getCursor(self, name=None):
        try:
            if name:
                self.cursor = self.connection.cursor(name)
            else:
                self.cursor = self.connection.cursor()
            return self.cursor
        except psycopg2.DatabaseError, e:
            self.log.error(e)

    def resultIter(self,curs,arraySize=1000):
        while True:
            results = curs.fetchmany(arraySize)
            if not results:
                break
            for result in results:
                yield result

    def close(self):
        try:
            self.cursor.close()
            self.connection.close()
            self.log.debug('Database Connection closed: {isClosed}'.format(isClosed=True))

            return True
        except psycopg2.DatabaseError, e:
            self.log.debug('Database Connection closed: {isClosed}'.format(isClosed=False))
            self.log.error(e)  


class Table(Connection):
    def __init__(self,database, table):

        Connection.__init__(self,database)

        self.create()
        self.curs = self.getCursor()
        self.name = table.lower()

    def tableExists(self):
        result = False
        sql = 'SELECT EXISTS( '\
                 'SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES '\
                    'WHERE TABLE_NAME=%(tableName)s '\
                 ')'
        self.log.debug(self.curs.mogrify(
            sql, {'tableName':(self.name)}
        )) 
        try:
            self.curs.execute(sql, {'tableName':(self.name)})
            result = self.curs.fetchone()[0]
            print('****connection.tableExists ',self.name)
        except psycopg2.DatabaseError, e:
            self.log.error(e)
            print('****Table does not exist****')
        self.log.debug('{tableName} Exists: {result}'
            .format(tableName=self.name, result=str(result)))
        #self.close()
        return result

    def createSpatialIndex(self):
        sql = 'CREATE INDEX %(layer)s_gix ON %(layer)s USING GIST (%(geom)s)'
        self.log.debug(self.curs.mogrify(
            sql, {'layer':(self.name),
                    'geom': 'geom'
                }
        )) 
        try:
            self.curs.execute(sql, 
                {'layer':(self.name),
                    'geom': 'geom'})
        except psycopg2.DatabaseError, e:
            self.log.error(e) 

    def vacuum(self):
        sql = 'VACUUM ANALYZE %(layer)s'
        self.log.debug(self.curs.mogrify(
            sql, {'layer':(self.name)}
        )) 
        try:
            self.curs.execute(sql, {'layer':(self.name)})
        except psycopg2.DatabaseError, e:
            self.log.error(e) 

    def spatialCluster(self):
        sql = 'CLUSTER %(layer)s USING %(layer)s_gix'
        self.log.debug(self.curs.mogrify(
            sql, {'layer':(self.name)}
        )) 
        try:
            self.curs.execute(sql, {'layer':(self.name)})
        except psycopg2.DatabaseError, e:
            self.log.error(e) 
        return result

    def createTable(self):
        sql = 'CREATE TABLE %(tableName)s ('\
                  'pk serial NOT NULL,'\
                  'cif_title character varying,'\
                  'cif_description character varying,'\
                  'assocLayer character varying,'\
                  'attr character varying,'\
                  'ogc_fid serial NOT NULL,'\
                  'layer_name character varying,'\
                  'requirement_id text,'\
                  'geom geometry, '\
                  'CONSTRAINT %(tableName)s_pkey PRIMARY KEY (pk)'\
            ')'
        self.log.debug(self.curs.mogrify(
            sql, {'tableName':AsIs(self.name)}
        )) 
        try:
            self.curs.execute(sql, {'tableName':AsIs(self.name)})
        except psycopg2.DatabaseError, e:
            self.log.error('Failed to Create Table: {tableName}'
                .format(tableName=self.name))
            self.log.error(e) 
        self.log.debug('{tableName} Created.'
            .format(tableName=self.name))

    def updateTable(self):
        print('*************connection.updateTable**************')
        sql = 'ALTER TABLE %(tableName)s '\
                'ADD COLUMN cif_description character varying, '\
                'ADD COLUMN assocLayer character varying, '\
                'ADD COLUMN attr character varying'

        self.log.debug(self.curs.mogrify(sql,{'tableName':AsIs(self.name)}))

        try:
            self.curs.execute(sql, {'tableName': AsIs(self.name)})
        except psycopg2.ProgrammingError, e:
            self.log.error(e)
            self.log.error('Failed to update table: {tableName}'.format(tableName=self.name))
        self.log.debug('{tableName} created.'.format(tableName=self.name))

    def updated(self):
        print('****connection.updated****')
        result = False
        sql = 'SELECT EXISTS( '\
                 'SELECT column_name FROM INFORMATION_SCHEMA.columns '\
                    'WHERE column_name = "cif_description" AND '\
                    'table_name = %(tableName)s'\
                 ')'
        self.log.debug(self.curs.mogrify(sql,{'tableName': self.name}))
        try:
            self.curs.execute(sql,{'tableName': self.name})
            result = self.curs.fetchone()[0]
            print('SUCCESS in having existing cif_description column')
        except psycopg2.DatabaseError, e:
            self.log.error(e)
            print('FAILED in having existing cif_description column')
        self.log.debug('{tableName} Updated: {result}'
            .format(tableName=self.name, result=str(result)))
        #self.close()
        return result