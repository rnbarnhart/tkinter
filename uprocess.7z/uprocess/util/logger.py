import logging
import sys

class Logger():
    def __init__(self, name, path, default=True):
        self.log = logging.getLogger(name)
        if not len(self.log.handlers):
			self.log.setLevel(logging.INFO)
			self.conLog = logging.StreamHandler(sys.stdout)
			formatter = logging.Formatter('%(asctime)s [%(name)s %(funcName)s:%(lineno)s] [%(levelname)s] %(message)s')
			self.conLog.setFormatter(formatter)
			self.log.addHandler(self.conLog)
                        if path: 
			    hdlr = logging.FileHandler('{}'.format(path))
			    hdlr.setFormatter(formatter)
			    self.log.addHandler(hdlr) 

    def getLoggerInstance(self):
        return self.log
