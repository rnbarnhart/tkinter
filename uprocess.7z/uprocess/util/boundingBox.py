from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT, AsIs
from multiprocessing import Process, Queue, Pool
import itertools
import sys, math
from connection import Connection
from metrics import Timer
from results import Results
from logger import Logger
from layer import Layer

class BoundingBox():
    def __init__(self, requirement_id, gdb, reviewNumber):
        self.boundbox = None
        self.log = (Logger('giLogger', 'test.log')).getLoggerInstance()
        self.gdb = gdb
        self.reviewNumber = reviewNumber
        self.requirement_id = requirement_id


    def boundBox(self, layerOne):

        boundingbox = []
        boundingboxcord = []
        boundinglist = dict()

        conn = Connection(self.gdb)
        self.log.debug('Connection to Database created.')
        conn.create()
        curs = conn.getCursor()
        #Note the F in ST_Relate - major differene between under and overshoots
        sqlStr ='SELECT ST_Extent(geom) FROM %(layerOne)s'

        self.log.debug(curs.mogrify(
            sqlStr, {'layerOne':AsIs(layerOne)}
        )) 
        curs.execute(
            sqlStr, {'layerOne':AsIs(layerOne)}
        )    
#        exist = curs.fetchone()
#        if exist is not None:
        rec = curs.fetchone()
        if rec[0] is not None:
            print rec
            #eliminates the layers that are empty
            if rec[0] is not None:
                boundingbox.append(rec[0])
            rec = curs.fetchone()

          
            for boxes in boundingbox:
                boxes = boxes.translate(None, "BOX()")
                boxes = boxes.split(",")
                for box in boxes:
                    box = box.split(" ")
                    if box not in boundingboxcord:
                        boundingboxcord.extend(box)
            boundboxcord = [float(x) for x in boundingboxcord]
            boundboxns = boundboxcord[::2]
            boundboxew = boundboxcord[1::2]
            print boundboxcord
            print boundboxns
            print boundboxew
            boundinglist['southlimit'] = min(boundboxns)
            boundinglist['northlimit'] = max(boundboxns)
            boundinglist['eastlimit'] = max(boundboxew)
            boundinglist['westlimit'] = min(boundboxew)

            boundinglist['swlimit'] = '({southlimit}, {westlimit})'.format(southlimit= boundinglist['southlimit'], westlimit=boundinglist['westlimit'])
            boundinglist['nelimit'] = '({northlimit}, {eastlimit})'.format(northlimit=boundinglist['northlimit'], eastlimit=boundinglist['eastlimit'])


            boundinglist['minboundbox'] = 'Minimal Bounding Box = BOX {swlimit}, {nelimit}'.format(swlimit=boundinglist['swlimit'], nelimit=boundinglist['nelimit'])
            print boundinglist['minboundbox']
        return boundinglist

    def multi(self,enabled=False):
        layerList = ['AeronauticCrv', 'AeronauticPnt', 'AeronauticSrf', 'AgriculturePnt', 'AgricultureSrf', 'BoundaryPnt', 'BoundarySrf', 'CultureCrv', 'CulturePnt', 'CultureSrf', 'FacilityPnt', 'FacilitySrf', 'HydroAidNavigationPnt', 'HydroAidNavigationSrf', 'HydrographyCrv', 'HydrographyPnt', 'HydrographySrf', 'HypsographyCrv', 'HypsographyPnt', 'IndustryCrv', 'IndustryPnt', 'IndustrySrf', 'InformationCrv', 'InformationPnt', 'InformationSrf', 'MilitaryCrv', 'MilitaryPnt', 'MilitarySrf', 'PhysiographyCrv', 'PhysiographyPnt', 'PhysiographySrf', 'PortHarbourCrv', 'PortHarbourPnt', 'PortHarbourSrf', 'RecreationCrv', 'RecreationPnt', 'RecreationSrf', 'SettlementPnt', 'SettlementSrf', 'StoragePnt', 'StorageSrf', 'StructureCrv', 'StructurePnt', 'StructureSrf', 'SubterraneanSrf', 'TransportationGroundCrv', 'TransportationGroundPnt', 'TransportationGroundSrf', 'TransportationWaterCrv', 'TransportationWaterPnt', 'TransportationWaterSrf', 'UtilityInfrastructureCrv', 'UtilityInfrastructurePnt', 'UtilityInfrastructureSrf', 'VegetationCrv', 'VegetationPnt', 'VegetationSrf', 'MetadataSrf', 'ResourceSrf']

        if enabled:
           raise ValueError('Multi-Processing not yet Implemented')
        else:
            for i in layerList:
                uResults = self.boundBox(i)

class CoordCalc():
    def __init__(self, gdb, proximityvar, maxdistvar, mindistvar, avglatmeter, avglongmeter):
        self.gdb = gdb
        self.conn = Connection(self.gdb)
        self.latdegvar = 0.0
        self.maxlongdegvar = 0.0
        self.minlongdegvar = 0.0
        self.longdegvar = 0.0
        self.maxlatdegvar = 0.0
        self.minlatdegvar = 0.0      
        self.latmetvar = proximityvar
        self.maxlongmetvar = maxdistvar
        self.minlongmetvar = mindistvar
        self.longmetvar = proximityvar
        self.maxlatmetvar = maxdistvar
        self.minlatmetvar = mindistvar
        self.endpointsgeom = []
        self.startpoints = []
        self.xstartpoints = []
        self.ystartpoints = []
        self.endpoints = []
        self.endpointsLayer = []
        self.xendpoints = []
        self.yendpoints = []
        self.ystartlist = []
        self.yendlist = []
        self.fcodeendpoints = []
        self.lonendbadnomatch = []
        self.lonendbadmatch = []
        self.lonfeaturenomatch = []
        self.latendbadnomatch = []
        self.latendbadmatch = []
        self.latfeaturenomatch = []

    def latlongcalc(self, boundingbox_values, layerOne):
        southlimit = boundingbox_values['southlimit']
        northlimit = boundingbox_values['northlimit']
        eastlimit = boundingbox_values['eastlimit']
        westlimit = boundingbox_values['westlimit']
        xfloor = math.floor(southlimit)
        xciel = math.ceil(northlimit)
        yfloor = math.floor(westlimit)
        yciel = math.ceil(eastlimit)
        print xfloor, xciel, yfloor, yciel
        xspan = range(int(xfloor), int(xciel + 1), 1)
        yspan = range(int(yfloor), int(yciel + 1), 1)
        intxspan = []
        intyspan = []
        intxspan.extend(xspan)
        intyspan.extend(yspan)
        self.conn.create()
        curs = self.conn.getCursor()
        print 'Here'
    #    del intxspan[0], intxspan[-1], intyspan[0], intyspan[-1]
           
        sqlStr ='SELECT ST_Distance(ST_PointFromText(\'Point(%(a)s %(b)s)\''\
                    ')::geometry, ST_PointFromText(\'Point(%(c)s %(b)s)\''\
                    ')::geometry) FROM %(layerOne)s'
        

        print(curs.mogrify(
            sqlStr, {'a':yfloor, 'b':xfloor, 'c':yciel, 'layerOne':AsIs(layerOne)}
        )) 
        curs.execute(
            sqlStr,{'a':yfloor, 'b':xfloor, 'c':yciel, 'layerOne':AsIs(layerOne)}
        )

        if (curs.rowcount > 0):
            dist = curs.fetchone()
            while dist is not None:
                longmeter = dist[0]
                dist = curs.fetchone()

        print(curs.mogrify(
            sqlStr, {'a':yfloor, 'b':xciel, 'c':yciel, 'layerOne':AsIs(layerOne)}
        ))   
        curs.execute(
            sqlStr,{'a':yfloor, 'b':xciel, 'c':yciel, 'layerOne':AsIs(layerOne)}
        )      
        if (curs.rowcount > 0):
            dist = curs.fetchone()
            while dist is not None:
                longmeter = dist[0]
                dist = curs.fetchone()

        print(curs.mogrify(
            sqlStr, {'a':xfloor, 'b':yfloor, 'c':xciel, 'layerOne':AsIs(layerOne)}
        ))    
        curs.execute(
            sqlStr,{'a':xfloor, 'b':yfloor, 'c':xciel, 'layerOne':AsIs(layerOne)}
        )      
        if (curs.rowcount > 0):
            dist = curs.fetchone()
            while dist is not None:
                latmeter = dist[0]
                dist = curs.fetchone()

        print(curs.mogrify(
            sqlStr, {'a':xfloor, 'b':yciel, 'c':xciel, 'layerOne':AsIs(layerOne)}
        )) 
        curs.execute(
            sqlStr,{'a':xfloor, 'b':yciel, 'c':xciel, 'layerOne':AsIs(layerOne)}
        )         
        if (curs.rowcount > 0):
            dist = curs.fetchone()
            while dist is not None:
                latmeter = dist[0]
                dist = curs.fetchone()


        avglongmeter = longmeter / len(yspan)
        avglatmeter = latmeter / len(xspan)
        xspan = map(int, xspan)
        yspan = map(int, yspan)

        print intxspan  
        print intyspan
        self.latdegvar = self.latmetvar / avglatmeter
        self.maxlongdegvar = self.maxlongmetvar / avglongmeter
        self.minlongdegvar = self.minlongmetvar / avglongmeter
        self.longdegvar = self.longmetvar / avglongmeter
        self.maxlatdegvar = self.maxlatmetvar / avglatmeter
        self.minlatdegvar = self.minlatmetvar / avglatmeter

        return self.latdegvar, self.maxlongdegvar, self.minlongdegvar, self.longdegvar, self.maxlatdegvar, self.minlatdegvar, intxspan, intyspan


if __name__ == "__main__":
    '''
    Devnote: This is for integration into the existing structure. 
        Eventually, remove this conditional and only use this __main__ for testing/other relevant logic .  
    '''
    if len(sys.argv) >= 6:
        requirement_id = str(sys.argv[1])
        gdb_name = str(sys.argv[4])
        review_num = int(sys.argv[5])
    else:
        requirement_id = 'Test'
        gdb_name = 'gdb_20170419_1026_200086_'
        review_num = '100'
        avglatmeter = 0.0
        avglongmeter = 0.0
        proximityvar = 0.10
        maxdistvar = 50.00
        mindistvar = 10.00
    layerList = ['AeronauticCrv', 'AeronauticPnt', 'AeronauticSrf', 'AgriculturePnt', 'AgricultureSrf', 'BoundaryPnt', 'BoundarySrf', 'CultureCrv', 'CulturePnt', 'CultureSrf', 'FacilityPnt', 'FacilitySrf', 'HydroAidNavigationPnt', 'HydroAidNavigationSrf', 'HydrographyCrv', 'HydrographyPnt', 'HydrographySrf', 'HypsographyCrv', 'HypsographyPnt', 'IndustryCrv', 'IndustryPnt', 'IndustrySrf', 'InformationCrv', 'InformationPnt', 'InformationSrf', 'MilitaryCrv', 'MilitaryPnt', 'MilitarySrf', 'PhysiographyCrv', 'PhysiographyPnt', 'PhysiographySrf', 'PortHarbourCrv', 'PortHarbourPnt', 'PortHarbourSrf', 'RecreationCrv', 'RecreationPnt', 'RecreationSrf', 'SettlementPnt', 'SettlementSrf', 'StoragePnt', 'StorageSrf', 'StructureCrv', 'StructurePnt', 'StructureSrf', 'SubterraneanSrf', 'TransportationGroundCrv', 'TransportationGroundPnt', 'TransportationGroundSrf', 'TransportationWaterCrv', 'TransportationWaterPnt', 'TransportationWaterSrf', 'UtilityInfrastructureCrv', 'UtilityInfrastructurePnt', 'UtilityInfrastructureSrf', 'VegetationCrv', 'VegetationPnt', 'VegetationSrf', 'MetadataSrf', 'ResourceSrf']

    bbox = BoundingBox(requirement_id,gdb_name,review_num)
    cif = CoordCalc(gdb_name, proximityvar, maxdistvar, mindistvar, avglatmeter, avglongmeter)
    for i in layerList:
        uResults = bbox.boundBox(i)
        if uResults:
            print 'answer ' + str(cif.latlongcalc(uResults, i))

