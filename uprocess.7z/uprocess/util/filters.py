#######################################################################################################
##
##   Authors: Michael Tackett, Theodore Terry, George Jarvis, Bob Meartz
##
##   Date: May 01, 2017
##
##   Written in Python 2.7.5, SQL portions are PostgreSQL 9.3 with PostGIS
##
##   Overall Python Dependencies (imports): none   
##
##   File name: filters.py
##
##   Description: Contains a selected list of layers to be applied conditional based on the criteria
##                of the CIF run.   
#######################################################################################################


class FilterLayer():
    def __init__(self):
        '''
        : Description: Initialization module. Controls the initialization of the layer instance
        
        : type self: instance variable
        : param self: refers to the reference of an instance variable used syntactically
        '''
        self.allLayers = self.getAllLayersList()
        self.allSrfLayers = self.getAllSrfLayerList()
        self.allCrvLayers = self.getAllCrvLayerList()
        self.allHallCrvLayerList = self.getAllCrvLayerList()
        self.halfCrvLayerList1 = self.getHalfCrvLayerList1()
        self.halfCrvLayerList2 = self.getHalfCrvLayerList2()
        self.allSrvCrvList = self.getAllSrfCrvList()
        self.allPntLayerList = self.getAllPntLayerList()
        self.Filter1 = self.getFilter1()
        self.grdtrans = self.getGrdtrans()
        self.bldg = self.getBldg()
        self.hydro = self.getHydro()
        self.PhysiographySrf = self.getPhysiographySrf()
        self.cif11CrvLayerList = self.getCif11CrvLayerList()
        self.transGrdCrv = self.getTransGrdCrv()
        self.filter25 = self.getFilter25()
        self.bldGrnd = self.getBldGrndTrans()
        self.bldHydro = self.getBldHydro()
        self.hydroGrnd = self.getHydroGrndTrans()
        self.filter27 = self.getFilter27()
        self.traGrnCrv = self.getTranGrndCrv()
        self.preCheckTest = self.getCIFpreCheck()
        self.cifLib = self.getcifLibDict()


    def getAllLayersList(self):
        '''
        : Description: This function contains all of the layers to be check against a GDB within a running CIF
        
        : type self: instance method
        : param self: refers to the reference of an instance variable used syntactically
        
        '''
        layerList = ["AeronauticCrv", "AeronauticPnt", "AeronauticSrf", "AgriculturePnt",
        "AgricultureSrf", "BoundaryPnt", "BoundarySrf", "CultureCrv", "CulturePnt",
        "CultureSrf", "FacilityPnt", "FacilitySrf", "HydroAidNavigationPnt",
        "HydroAidNavigationSrf", "HydrographyCrv", "HydrographyPnt", "HydrographySrf",
        "HypsographyCrv", "HypsographyPnt", "IndustryCrv", "IndustryPnt", "IndustrySrf",
        "InformationCrv", "InformationPnt", "InformationSrf", "MilitaryCrv", "MilitaryPnt",
        "MilitarySrf", "PhysiographyCrv", "PhysiographyPnt", "PhysiographySrf",
        "PortHarbourCrv", "PortHarbourPnt", "PortHarbourSrf", "RecreationCrv", "RecreationPnt",
        "RecreationSrf", "SettlementPnt", "SettlementSrf", "StoragePnt", "StorageSrf",
        "StructureCrv", "StructurePnt", "StructureSrf", "SubterraneanSrf",
        "TransportationGroundCrv", "TransportationGroundPnt", "TransportationGroundSrf",
        "TransportationWaterCrv", "TransportationWaterPnt", "TransportationWaterSrf",
        "UtilityInfrastructureCrv", "UtilityInfrastructurePnt", "UtilityInfrastructureSrf",
        "VegetationCrv", "VegetationPnt", "VegetationSrf", "MetadataSrf", "ResourceSrf"]
        return layerList

    def getAllSrfLayerList(self):
        '''
        : Description: This function contains all surface layers to be check against a GDB within a running CIF
        
        : type self: instance method
        : param self: refers to the reference of an instance variable used syntactically
        
        '''
        layerList = ["AeronauticSrf", "AgricultureSrf", "BoundarySrf", "CultureSrf",
        "FacilitySrf", "HydroAidNavigationSrf", "HydrographySrf", "IndustrySrf",
        "InformationSrf", "MilitarySrf", "PhysiographySrf", "PortHarbourSrf", "RecreationSrf",
        "SettlementSrf", "StorageSrf", "StructureSrf", "SubterraneanSrf", 
        "TransportationGroundSrf", "TransportationWaterSrf", "UtilityInfrastructureSrf",
        "VegetationSrf", "MetadataSrf", "ResourceSrf"]
        return layerList

    def getAllCrvLayerList(self):
        '''
        : Description: This function contains all curved layers to be check against a GDB within a running CIF
        
        : type self: instance method
        : param self: refers to the reference of an instance variable used syntactically
        
        '''
        layerList = ["AeronauticCrv", "TransportationGroundCrv", "HydrographyCrv","CultureCrv", "HypsographyCrv", "IndustryCrv", "InformationCrv", "MilitaryCrv",
        "PortHarbourCrv", "RecreationCrv", "StructureCrv", "TransportationWaterCrv","UtilityInfrastructureCrv", "VegetationCrv", "PhysiographyCrv"]
        return layerList

    def getHalfCrvLayerList1(self):
        '''
        : Description: This function contains half curved layers to be check against a GDB within a running CIF
        
        : type self: instance method
        : param self: refers to the reference of an instance variable used syntactically
        
        '''
        layerList = ["HydrographyCrv", "AeronauticCrv", "CultureCrv", "HypsographyCrv",
        "IndustryCrv", "InformationCrv", "MilitaryCrv"] 
        return layerList

    def getHalfCrvLayerList2(self):
        '''
        : Description: This function contains half curved layers to be check against a GDB within a running CIF
        
        : type self: instance method
        : param self: refers to the reference of an instance variable used syntactically
        
        '''
        layerList = ["TransportationGroundCrv", "PhysiographyCrv", "PortHarbourCrv",
        "RecreationCrv", "StructureCrv", "TransportationWaterCrv", "UtilityInfrastructureCrv",
        "VegetationCrv"] #"StructureCrv", 
        return layerList

    def getAllSrfCrvList(self):
        '''
        : Description: This function contains all of the surface curved layers to be check against a GDB within a running CIF
        
        : type self: instance method
        : param self: refers to the reference of an instance variable used syntactically
        
        '''
        
        layerList = ["AeronauticSrf", "AgricultureSrf", "BoundarySrf", "CultureSrf",
        "FacilitySrf", "HydroAidNavigationSrf", "HydrographySrf", "IndustrySrf",
        "InformationSrf", "MilitarySrf", "PhysiographySrf", "PortHarbourSrf", "RecreationSrf",
        "SettlementSrf", "StorageSrf", "StructureSrf", "SubterraneanSrf",
        "TransportationGroundSrf", "TransportationWaterSrf", "UtilityInfrastructureSrf",
        "VegetationSrf", "MetadataSrf", "ResourceSrf", "AeronauticCrv", "CultureCrv",
        "HydrographyCrv", "HypsographyCrv", "IndustryCrv", "InformationCrv", "MilitaryCrv",
        "PhysiographyCrv", "PortHarbourCrv", "RecreationCrv", "StructureCrv",
        "TransportationGroundCrv", "TransportationWaterCrv", "UtilityInfrastructureCrv",
        "VegetationCrv"]
        return layerList

    def getAllPntLayerList(self):
        '''
        : Description: This function contains all point layers to be check against a GDB within a running CIF
        
        : type self: instance method
        : param self: refers to the reference of an instance variable used syntactically
        
        '''            
        layerList = ["AeronauticPnt", "AgriculturePnt", "BoundaryPnt", "CulturePnt","FacilityPnt", "HydroAidNavigationPnt", "HydrographyPnt", "HypsographyPnt",
        "IndustryPnt", "InformationPnt", "MilitaryPnt", "PhysiographyPnt", "PortHarbourPnt","RecreationPnt", "SettlementPnt", "StoragePnt", "StructurePnt",
        "TransportationGroundPnt", "TransportationWaterPnt", "UtilityInfrastructurePnt","VegetationPnt"]
        return layerList

    def getFilter1(self):
        '''
        : Description: This function contains a potpourri of surface layers to be check against a GDB within a running CIF
        
        : type self: instance method
        : param self: refers to the reference of an instance variable used syntactically
        
        '''
        layerList = ["TransportationGroundSrf", "IndustrySrf", "AgricultureSrf","HydrographySrf", "VegetationSrf", "MilitarySrf", "SettlementSrf","HydroAidNavigationSrf", "InformationSrf", "AeronauticSrf", "PhysiographySrf","RecreationSrf", "UtilityInfrastructureSrf", "StorageSrf", "PortHarbourSrf",
        "FacilitySrf", "SubterraneanSrf", "CultureSrf", "TransportationWaterSrf","StructureSrf", "BoundarySrf"]
        return layerList

    def getGrdtrans(self):
        '''
        : Description: This function contains a list of ground transportation layers to be check against a GDB within a running CIF
        
        : type self: instance method
        : param self: refers to the reference of an instance variable used syntactically
        
        '''
        
        layerList = ["TransportationGroundSrf", "TransportationGroundCrv",
        "TransportationGroundPnt"]
        return layerList

    def getBldg(self):
        '''
        : Description: This function contains structured layers to be check against a GDB within a running CIF
        
        : type self: instance method
        : param self: refers to the reference of an instance variable used syntactically
        
        '''
        
        layerList = ["StructureCrv", "StructurePnt", "StructureSrf"]
        return layerList

    def getHydro(self):
        '''
        : Description: This function contains hydrography layers to be check against a GDB within a running CIF
        
        : type self: instance method
        : param self: refers to the reference of an instance variable used syntactically
        
        '''
        
        layerList = ["HydrographyCrv", "HydrographyPnt", "HydrographySrf"]
        return layerList

    def getBldGrndTrans(self):
        layerList = ["TransportationGroundSrf", "TransportationGroundCrv", "TransportationGroundPnt", "StructureCrv", "StructurePnt", "StructureSrf"]
        return layerList

    def getBldHydro(self):
        layerList = ["HydrographyCrv", "HydrographyPnt", "HydrographySrf", "StructureCrv", "StructurePnt", "StructureSrf"]
        return layerList

    def getHydroGrndTrans(self):
        layerList = ["TransportationGroundSrf", "TransportationGroundCrv", "TransportationGroundPnt", "HydrographyCrv", "HydrographyPnt", "HydrographySrf"]
        return layerList

    def getPhysiographySrf(self):
        '''
        : Description: This function contains physiography surface layers to be check against a GDB within a running CIF
        
        : type self: instance method
        : param self: refers to the reference of an instance variable used syntactically
        
        '''
        
        layerList = ["AgricultureSrf", "HydrographySrf", "IndustrySrf", "InformationSrf",
        "SettlementSrf", "TransportationWaterSrf", "VegetationSrf"] ###"formally filter7 " 
        return layerList

    def getCif11CrvLayerList(self):
        '''
        : Description: This function contains hydrography layer to be check against a GDB within a running CIF
        
        : type self: instance method
        : param self: refers to the reference of an instance variable used syntactically
        
        '''
        
        layerList = ["HydrographyCrv"]
        return layerList

    def getTransGrdCrv(self):
        '''
        : Description: This function contains transportation ground curve layer to be check against a GDB within a running CIF
        
        : type self: instance method
        : param self: refers to the reference of an instance variable used syntactically
        
        '''
        
        layerList = ["TransportationGroundCrv"] ### formally filter6, filter19, filter20
        return layerList

    def getFilter25(self):
        '''
        : Description: This function contains hydography and transportation layers to be check against a GDB within a running CIF
        
        : type self: instance method
        : param self: refers to the reference of an instance variable used syntactically
        
        '''

        layerList = ["HydrographySrf", "HydrographyCrv", "TransportationWaterCrv",
        "TransportationWaterSrf", "TransportationGroundCrv", "TransportationGroundPnt"]
        return layerList

    def getFilter27(self):
        '''
        : Description: This function contains facility and structure layers to be check against a GDB within a running CIF
        
        : type self: instance method
        : param self: refers to the reference of an instance variable used syntactically
        
        '''

        layerList = ["FacilityPnt", "FacilitySrf", "StructureCrv", "StructurePnt",
        "StructureSrf"]
        return layerList

    def getCIFpreCheck(self):
        #layerList = [self.bldHydro, [1]], [self.hydroGrnd, [2]], [self.filter27, [3]]
        layerDict = ["AeronauticCrv", "AeronauticPnt", "AeronauticSrf", "AgriculturePnt", "AgricultureSrf", "BoundaryPnt", "BoundarySrf", "CultureCrv", "CulturePnt", "CultureSrf", "FacilityPnt", "FacilitySrf", "HydroAidNavigationPnt", "HydroAidNavigationSrf", "HydrographyCrv", "HydrographyPnt", "HydrographySrf", "HypsographyCrv", "HypsographyPnt", "IndustryCrv", "IndustryPnt", "IndustrySrf", "InformationCrv", "InformationPnt", "InformationSrf", "MilitaryCrv", "MilitaryPnt", "MilitarySrf", "PhysiographyCrv", "PhysiographyPnt", "PhysiographySrf", "PortHarbourCrv", "PortHarbourPnt", "PortHarbourSrf", "RecreationCrv", "RecreationPnt", "RecreationSrf", "SettlementPnt", "SettlementSrf", "StoragePnt", "StorageSrf", "StructureCrv", "StructurePnt", "StructureSrf", "SubterraneanSrf", "TransportationGroundCrv", "TransportationGroundPnt", "TransportationGroundSrf", "TransportationWaterCrv", "TransportationWaterPnt", "TransportationWaterSrf", "UtilityInfrastructureCrv", "UtilityInfrastructurePnt", "UtilityInfrastructureSrf", "VegetationCrv", "VegetationPnt", "VegetationSrf", "MetadataSrf", "ResourceSrf"]
        return layerDict

    def getTranGrndCrv(self):
        layerList = ["TransportationGroundCrv"]

        return layerList

    def getcifLibDict(self):
        layerDict = {'CIF_1':self.Filter1, 'CIF_2':self.allLayers, 'CIF_3':self.bldGrnd, 'CIF_4':self.bldHydro, 'CIF_5':self.hydroGrnd, 'CIF_6':self.traGrnCrv, 'CIF_7':self.allLayers, 'CIF_8':self.allLayers,'CIF_9':self.allLayers, 'CIF_10':self.allSrvCrvList, 'CIF_11':self.allCrvLayers, 'CIF_12':self.allCrvLayers, 'CIF_13':self.allLayers, 'CIF_14':self.allLayers, 'CIF_15':self.allLayers,'CIF_16':self.allLayers, 'CIF_17':self.allCrvLayers, 'CIF_18':self.allLayers, 'CIF_19':self.allLayers, 'CIF_20':self.allLayers, 'CIF_22':self.allLayers, 'CIF_25':self.filter25, 'CIF_26':self.allSrvCrvList, 'CIF_27':self.filter27}

        return layerDict