import ConfigParser
import os

class Configuration: 
	def __init__(self, path=None):
		self.Config = ConfigParser.ConfigParser()
		if not path: 
			#Try to find the config file locally. 
			#path = '/scripts/util/config.ini'
			path = 'config.ini'
		path = os.getcwd() + path
		self.Config.read(path)

	#See python/org/moin/ConfigParserExample
	def mapSection(self,section):
		configDict = {}
		options = self.Config.options(section)
		for option in options:
			try:
				configDict[option] = self.Config.get(section,option)
				if configDict[option] == -1:
					self.log.info('Config option ({option}) not found. '.format(option=option))
			except: 
				self.log.error('Exception with config option: {option}'.format(option=option))
				configDict[option] = None
		return configDict

#For testing. 
if __name__ == '__main__':
	config = Configuration()
	print config.mapSection('Application')
