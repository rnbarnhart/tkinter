import logging, zipfile

def unzipfile(zipFilePathName):
    logging.info('Unzipping file.')
    zip_ref = zipfile.ZipFile(zipFilePathName,'r')
    zip_ref.extractall('temp')
    for x in zip_ref.infolist():
        fname = x.filename
        break;
    zip_ref.close
    logging.info('File unzipped.')
    return fname